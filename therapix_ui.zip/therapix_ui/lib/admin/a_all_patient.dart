import 'package:flutter/material.dart';
import 'package:therapix_ui/admin/a_drawer.dart';
import 'package:therapix_ui/loginPage.dart';

class A_All_Patient extends StatefulWidget {
  const A_All_Patient({super.key});

  @override
  State<A_All_Patient> createState() => _A_All_PatientState();
}

class _A_All_PatientState extends State<A_All_Patient> {
  String? selectedItem;
  String dropdownvalue = '10';
  var items = [
    '10',
    '20',
    '50',
    'All'
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "All Patient",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Admin User",
                child: Text("Admin User"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              margin: EdgeInsets.all(4),
              padding: EdgeInsets.all(4),
              color: Colors.white,
              child: Column(
                children: [
                  Row(
                    children: [
                      SizedBox(width: 5,),
                      Text("Patient List", style: TextStyle(fontSize: 30,fontWeight: FontWeight.w700,),),
                      SizedBox(width: 5,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: customColor("#0F6A8D"),
                          ),
                          child: Text("No Settled Patient",style: TextStyle(color: Colors.white),)
                      ),
                      SizedBox(width: 3,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("+ New",style: TextStyle(color: Colors.white),)
                      ),
                    ],
                  ),
                  SizedBox(height: 15,),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        "Search",
                        style: TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: 12,
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height-825,
                        width: MediaQuery.of(context).size.width-100,
                        child: TextField(
                          decoration: InputDecoration(border: OutlineInputBorder(),
                              hintText: "Search Patient"),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("Search",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)
                      ),
                      SizedBox(width: 20,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red
                          ),
                          child: Text("Clear",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      DropdownButton(
                          value: dropdownvalue,
                          items: items.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:30),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              dropdownvalue=newValue!;
                            });
                          }),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height-800,
                    width: MediaQuery.of(context).size.width-120,
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Search ",
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      border: TableBorder.all(color: Colors.black),
                      columns: [
                        DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("ACTION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("MOBILE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("AGE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("GENDER", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("CITY", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("ADDRESS", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("OCCUPATION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("DATE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("DEPARTMENT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("PACKAGES", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("DAYS", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("TOTAL AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("RECEIVED AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("DUE AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("REFERRAL BY", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("DESCRIPTION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      ],
                      rows: [
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("button")),
                          DataCell(Text("Dixit Dobariya")),
                          DataCell(Text("9999999999")),
                          DataCell(Text("0")),
                          DataCell(Text("Male")),
                          DataCell(Text("Rajkot")),
                          DataCell(Text("Rajkot")),
                          DataCell(Text("Business")),
                          DataCell(Text("1-1-2025")),
                          DataCell(Text("neuro")),
                          DataCell(Text("neuro")),
                          DataCell(Text("5")),
                          DataCell(Text("2500")),
                          DataCell(Text("- -")),
                          DataCell(Text("0")),
                          DataCell(Text("Self")),
                          DataCell(Text("wsda")),
                        ],),
                      ],
                    ),
                  ),
                  SizedBox(height: 10,),
                ],
              ),
            )
          ],
        ),
      ),
      drawer: A_Drawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
