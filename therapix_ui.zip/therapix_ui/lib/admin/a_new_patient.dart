import 'package:flutter/material.dart';
import 'package:therapix_ui/admin/a_drawer.dart';
import 'package:therapix_ui/loginPage.dart';

class A_New_Patient extends StatefulWidget {
  const A_New_Patient({super.key});

  @override
  State<A_New_Patient> createState() => _A_New_PatientState();
}

class _A_New_PatientState extends State<A_New_Patient> {
  String? selectedItem;
  String dropdownvalue = '10';
  var items = [
    '10',
    '20',
    '50',
    '100',
    'All'
  ];
  String departmentdropdownvalue = 'Select Department';
  var department = [
    'Select Department',
    'Ortho',
    'Paediatric',
    'Neuro',
    'Home Ortho',
    'Home Paediatric',
    'Home Neuro'
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "New Patiet",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 25,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Admin User",
                child: Text("Admin User"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(4),
              padding: EdgeInsets.all(4),
              color: Colors.white,
              child: Column(
                children: [
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text("Start Date",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                      SizedBox(width: 20,),
                      SizedBox(
                        height: MediaQuery.of(context).size.height/22,
                        width: MediaQuery.of(context).size.width-125,
                        child: TextField(
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: "Enter Start Date"
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text("End Date",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                      SizedBox(width: 27,),
                      SizedBox(
                        height: MediaQuery.of(context).size.height/22,
                        width: MediaQuery.of(context).size.width-125,
                        child: TextField(
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: "Enter End Date"
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text("Department",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                      SizedBox(width: 1,),
                      SizedBox(
                        width: 275,
                        child: DropdownButton(
                          padding: EdgeInsets.all(4),
                          value: departmentdropdownvalue,
                          items: department.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:20),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              departmentdropdownvalue= newValue!;
                            });
                          },
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("Search",style: TextStyle(color: Colors.white),)
                      ),
                      SizedBox(width: 10,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red
                          ),
                          child: Text("Clear",style: TextStyle(color: Colors.white),)
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("Copy",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("Excel",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("CSV",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("PDF",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("Print",style: TextStyle(color: Colors.black),)
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      DropdownButton(
                          value: dropdownvalue,
                          items: items.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:30),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              dropdownvalue=newValue!;
                            });
                          }),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height-800,
                    width: MediaQuery.of(context).size.width-120,
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Search ",
                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                        dataRowMaxHeight: double.infinity,
                        border: TableBorder.all(color: Colors.black),
                        columns: [
                          DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("MOBILE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("AGE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("GENDER", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("CITY", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("ADDRESS", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("OCCUPATION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DATE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DEPARTMENT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("PACKAGE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DAYS", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("TOTAL AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DUE AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("REFER BY", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        ],
                        rows: const [
                          DataRow(cells: [
                            DataCell(Text("1")),
                            DataCell(Text("Dixit Dobariya")),
                            DataCell(Text("999999999")),
                            DataCell(Text("0")),
                            DataCell(Text("Male")),
                            DataCell(Text("Rajkot")),
                            DataCell(Text("Rajkot")),
                            DataCell(Text("IT")),
                            DataCell(Text("19-12-2024")),
                            DataCell(Text(" ")),
                            DataCell(Text(" ")),
                            DataCell(Text(" ")),
                            DataCell(Text(" ")),
                            DataCell(Text("0")),
                            DataCell(Text("WSDA")),
                          ],),
                        ]),
                  )
                ],
              ),
            )
          ],
        ),
      ),
      drawer: A_Drawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
