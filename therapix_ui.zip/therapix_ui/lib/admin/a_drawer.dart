import 'package:flutter/material.dart';
import 'package:therapix_ui/admin/a_add_new_patient.dart';
import 'package:therapix_ui/admin/a_all_patient.dart';
import 'package:therapix_ui/admin/a_bill_report.dart';
import 'package:therapix_ui/admin/a_calender.dart';
import 'package:therapix_ui/admin/a_dashboard.dart';
import 'package:therapix_ui/admin/a_doctor_schedule.dart';
import 'package:therapix_ui/admin/a_due_payment.dart';
import 'package:therapix_ui/admin/a_feedback.dart';
import 'package:therapix_ui/admin/a_graph.dart';
import 'package:therapix_ui/admin/a_holiday.dart';
import 'package:therapix_ui/admin/a_new_patient.dart';
import 'package:therapix_ui/admin/a_rec_payment.dart';
import 'package:therapix_ui/admin/a_ref_person.dart';
import 'package:therapix_ui/admin/a_rev_rep_all.dart';
import 'package:therapix_ui/admin/a_rev_rep_staff.dart';
import 'package:therapix_ui/admin/a_staff_manegment.dart';
import 'package:therapix_ui/admin/a_treatment_rep.dart';
import 'package:therapix_ui/admin/a_treatment_staff.dart';
import 'package:therapix_ui/admin/a_unsettle_patient.dart';

class A_Drawer extends StatefulWidget {
  const A_Drawer({super.key});

  @override
  State<A_Drawer> createState() => _A_DrawerState();
}

class _A_DrawerState extends State<A_Drawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: customColor("#0F6A8D"),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              color: customColor("#0F6A8D"),
            ),
            accountName: const Text(
              "Admin Panel",
              style: TextStyle(fontSize: 25),
            ),
            accountEmail: const Text(""),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Dashboard()),),
            child: const ListTile(
              leading: Icon(Icons.home, color: Colors.white),
              title: Text("Dashboard", style: TextStyle(color: Colors.white)),
            ),
          ),
          ExpansionTile(
            leading: Icon(Icons.person, color: Colors.white),
            title: Text("Patient", style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Settled_Patient()),),
                  child: ListTile(title: Text("Unsettled Patient",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_All_Patient()),),
                  child: ListTile(title: Text("All Patient",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Add_New()),),
                  child: ListTile(title: Text("Add New Patient",style: TextStyle(color: Colors.white),),)),
            ],
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Calender()),),
            child: const ListTile(
              leading: Icon(Icons.calendar_month_outlined, color: Colors.white),
              title: Text("Calender", style: TextStyle(color: Colors.white)),
            ),
          ),
          ExpansionTile(
            title: Text("Doctor's Schedule",style: TextStyle(color: Colors.white),),
            leading: Icon(Icons.watch_later, color: Colors.white,),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Doctor_Schedule()),),
                  child: ListTile(title: Text("Rajkot",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Doctor_Schedule()),),
                  child: ListTile(title: Text("Surat",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Doctor_Schedule()),),
                  child: ListTile(title: Text("Ahmedabad",style: TextStyle(color: Colors.white),),))
            ],
          ),
          ExpansionTile(
            leading: Icon(Icons.featured_play_list_outlined, color: Colors.white),
            title: Text("Reports", style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Due_Payment()),),
                  child: ListTile(title: Text("Due Payment Report",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Treatment_Rep()),),
                  child: ListTile(title: Text("Treatment Report",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Rev_Rep_Staff()),),
                  child: ListTile(title: Text("Revenue Report By Staff",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Treatment_Staff()),),
                  child: ListTile(title: Text("Treatment By Staff",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Rev_Rep_all()),),
                  child: ListTile(title: Text("Revenue Report By All",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Rec_payment()),),
                  child: ListTile(title: Text("Received Payment By Day",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_New_Patient()),),
                  child: ListTile(title: Text("New Patient",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Bill_Report()),),
                  child: ListTile(title: Text("Bill Report",style: TextStyle(color: Colors.white),),)),
            ],
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Ref_Per()),),
            child: const ListTile(
              leading: Icon(Icons.chat, color: Colors.white),
              title: Text("Referral Person", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Graph()),),
            child: const ListTile(
              leading: Icon(Icons.auto_graph, color: Colors.white),
              title: Text("Graph", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Staff_Management()),),
            child: const ListTile(
              leading: Icon(Icons.person, color: Colors.white),
              title: Text("Staff Management", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Holidays()),),
            child: const ListTile(
              leading: Icon(Icons.star, color: Colors.white),
              title: Text("Holidays", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>A_Feedback()),),
            child: const ListTile(
              leading: Icon(Icons.feedback_outlined, color: Colors.white),
              title: Text("Feedback Form", style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
