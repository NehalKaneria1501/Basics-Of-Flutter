import 'package:flutter/material.dart';
import 'package:therapix_ui/admin/a_drawer.dart';
import 'package:therapix_ui/loginPage.dart';

class A_Add_New extends StatefulWidget {
  const A_Add_New({super.key});

  @override
  State<A_Add_New> createState() => _A_Add_NewState();
}

class _A_Add_NewState extends State<A_Add_New> {
  String? selectedItem;
  String dropdownvalue = 'Self';
  var items = [
    'Self',
    'Dixit Dobariya',
    'Dixit Dobariya',
    'Dixit Dobariya'
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "New Patient",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Admin User",
                child: Text("Admin User"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: Colors.white,
              ),
              margin: EdgeInsets.all(6),
              padding: EdgeInsets.all(15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "First Name",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter First Name"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Middle Name",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Middle Name"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Last Name",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Last Name"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Contact",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Contact Number"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Alternate Contact",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Alternate Contact"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "City Name",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter City Name"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Address",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Your Address"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "BirthDate",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Birthdate"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Gender",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Gender"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Occupation",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Occupation Name"
                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Date",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Enter Date"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Description",
                    style: TextStyle(
                        fontSize: 23,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10,),
                  SizedBox(
                    height: MediaQuery.of(context).size.height/18,
                    width: MediaQuery.of(context).size.width,
                    child: TextField(
                      decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Add Description of Patient"),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text("Person" ,style: TextStyle(
                          fontSize: 23,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),),
                      SizedBox(width: 100,),
                      DropdownButton(
                          value: dropdownvalue,
                          items: items.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:25),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              dropdownvalue=newValue!;
                            });
                          }
                      ),
                    ],
                  ),
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("Submit",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)
                      ),
                      SizedBox(width: 20,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red
                          ),
                          child: Text("Cancel",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)
                      ),
                      SizedBox(height: 20,)
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
      drawer: A_Drawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
