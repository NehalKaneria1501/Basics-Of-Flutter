import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/homePage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey=GlobalKey<FormState>();
  bool valuefirst = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 120,),
              Image.asset("assets/images/TherapixFullLogo.png", height: 250, width: 350,),
              // SizedBox(height: 0,),
              // Text("Welcome to Digital CRM Software", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 35 , ),textAlign: TextAlign.center,),
              // SizedBox(height: 13,),
              // Text("It is a great day today !" , style: TextStyle(fontSize: 18),),
              // SizedBox(height: 20,),
              Container(
                key: _formKey,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
                  color: Colors.white,
                ),
                height: MediaQuery.of(context).size.width,
                width: 350,
                margin: EdgeInsets.all(15.0),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      SizedBox( height: 0,),
                      // Container(
                      //   height: 55,
                      //   width: 350,
                      //   decoration: BoxDecoration(
                      //     borderRadius: BorderRadius.circular(8.0),
                      //     gradient: LinearGradient(
                      //       colors:  [ Color(0xFF351D07), Color(0xFFE7BD48)],
                      //     )
                      //   ),
                      //   padding: EdgeInsets.all(12.0),
                      //   child: Text("Please Sign In",style: TextStyle(fontSize: 23 , color: Colors.white, fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
                      // ),
                      SizedBox(height: 0,),
                      Container(
                        margin: EdgeInsets.all(0),
                        padding: EdgeInsets.all(8),
                        child: TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            hintText: 'Enter Your User Name',
                            labelText: 'Username',
                          ),
                          validator: (value){
                            if(value!.isEmpty){
                              return 'Please Enter Your valid Name';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 0,),
                      Container(
                        margin: EdgeInsets.all(0),
                        padding: EdgeInsets.all(8),
                        child: TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.grey,
                            border: OutlineInputBorder(),
                            hintText: 'Enter Your Password',
                            labelText: 'Password',
                          ),
                          validator: (value){
                            if(value!.isEmpty){
                              return 'Please Enter Your Password';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 10,),
                      // Row(
                      //   children: <Widget> [
                      //     Checkbox(
                      //       checkColor: Colors.black,
                      //       activeColor: Colors.white,
                      //       value: this.valuefirst,
                      //       onChanged: (value){
                      //         setState(() {
                      //           this.valuefirst=value!;
                      //         });
                      //       },
                      //     ),
                      //     Text("Remember Me"),
                          SizedBox(
                            width: 75,
                          ),
                          Container(
                            width: 350,
                            height: 60,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor:Color(customColor("#0F6A8D"))
                              ),
                              onPressed: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>HomePage()));
                              },
                              child: const Text('Sign In',style: TextStyle(color: Colors.white,fontSize: 25),
                                textAlign: TextAlign.end,),
                            ),
                          ),
                        ],
                      ),
                      // SizedBox( height: 5,),
                      // Container(
                      //   margin: EdgeInsets.only(right: 40),
                      //   child: Row(
                      //     mainAxisAlignment: MainAxisAlignment.end,
                      //     children: [
                      //       RichText(
                      //         text: TextSpan(
                      //           text: 'Forgot Password',
                      //           style: TextStyle(color: Colors.blue,decoration: TextDecoration.underline),
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
int customColor(String colorCode){
  String colors= "0xff"+ colorCode ;
  colors=colors.replaceAll("#", "");
  return int.parse(colors);
}