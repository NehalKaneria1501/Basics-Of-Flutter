import 'package:flutter/material.dart';
import 'package:therapix_ui/loginPage.dart';
import 'package:therapix_ui/staff/s_drawer.dart';

class S_Doctor_Schedule extends StatefulWidget {
  const S_Doctor_Schedule({super.key});

  @override
  State<S_Doctor_Schedule> createState() => _S_Doctor_ScheduleState();
}

class _S_Doctor_ScheduleState extends State<S_Doctor_Schedule> {
  String? selectedItem;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Doctors Schedule",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Staff Panel",
                child: Text("Staff Panel"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(8),
            margin: EdgeInsets.all(4),
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: Colors.white,
            ),
            child: Text("Branch",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
          ),
          SizedBox(height: 10,),
          Container(
            margin: EdgeInsets.all(2),
            padding: EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Text("Date",style: TextStyle(fontSize: 25,fontWeight: FontWeight.w700),),
                    SizedBox(width: 10,),
                    SizedBox(
                      width: MediaQuery.of(context).size.width/1.8,
                      height: MediaQuery.of(context).size.height/20,
                      child: TextField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Enter Date here",
                        ),
                      ),
                    ),
                    SizedBox(width: 10,),
                    ElevatedButton(onPressed: (){
                      print("abc");
                    },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: customColor("#0F6A8D")
                        ),
                        child: Text("Search",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  children: [
                    Text("Is Free", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                  ],
                ),
                SizedBox(height: 5,),
                Row(
                  children: [
                    Text("Not Free", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                  ],
                ),
                SizedBox(height: 5,),
                Row(
                  children: [
                    Text("Not Available", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                  ],
                ),
                SizedBox(height: 10,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    border: TableBorder.all(color: Colors.black),
                    columns: [
                      DataColumn(label: Text("#" ,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("Staff Name" , style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("8.00 - 8.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("8.30 - 9.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("9.00 - 9.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("9.30 - 10.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("10.00 - 10.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("10.30 - 11.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("11.00 - 11.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("11.30 - 12.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("12.00 - 12.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("12.30 - 13.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("13.00 - 13.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("13.30 - 14.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("16.00 - 16.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("16.30 - 17.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("17.00 - 17.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("17.30 - 18.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("18.00 - 18.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("18.30 - 19.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("19.00 - 19.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("19.30 - 20.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("20.00 - 20.30", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("20.30 - 21.00", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),

                    ],
                    rows: [
                      DataRow(cells: [
                        DataCell(Text("1")),
                        DataCell(Text("Dixit Dobariya")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                      ],),
                      DataRow(cells: [
                        DataCell(Text("1")),
                        DataCell(Text("Dixit Dobariya")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                      ],),
                      DataRow(cells: [
                        DataCell(Text("1")),
                        DataCell(Text("Dixit Dobariya")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                        DataCell(Text("*")),
                      ],),
                    ],
                  ),
                ),
                SizedBox(height: 10,)
              ],
            ),
          )
        ],
      ),
      drawer: S_Drawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
