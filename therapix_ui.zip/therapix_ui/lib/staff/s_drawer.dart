import 'package:flutter/material.dart';
import 'package:therapix_ui/staff/S_Calender.dart';
import 'package:therapix_ui/staff/S_Doctor_Schedule.dart';
import 'package:therapix_ui/staff/s_add_new_patient.dart';
import 'package:therapix_ui/staff/s_all_patient.dart';
import 'package:therapix_ui/staff/s_dashboard.dart';
import 'package:therapix_ui/staff/s_due_payment.dart';
import 'package:therapix_ui/staff/s_graph.dart';
import 'package:therapix_ui/staff/s_holiday.dart';
import 'package:therapix_ui/staff/s_rev_rep.dart';
import 'package:therapix_ui/staff/s_staff_rec_pay.dart';
import 'package:therapix_ui/staff/s_staff_treatment.dart';
import 'package:therapix_ui/staff/s_unsettled_patient.dart';

class S_Drawer extends StatefulWidget {
  const S_Drawer({super.key});

  @override
  State<S_Drawer> createState() => _S_DrawerState();
}

class _S_DrawerState extends State<S_Drawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: customColor("#0F6A8D"),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              color: customColor("#0F6A8D"),
            ),
            accountName: const Text(
              "Doctor's Panel",
              style: TextStyle(fontSize: 25),
            ),
            accountEmail: const Text(""),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Dashboard()),),
            child: const ListTile(
              leading: Icon(Icons.home, color: Colors.white),
              title: Text("Dashboard", style: TextStyle(color: Colors.white)),
            ),
          ),
          ExpansionTile(
            leading: Icon(Icons.person, color: Colors.white),
            title: Text("Patient", style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Unsettled_Patient()),),
                  child: ListTile(title: Text("Unsettled Patient",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_All_Patient()),),
                  child: ListTile(title: Text("All Patient",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Add_New()),),
                  child: ListTile(title: Text("Add New Patient",style: TextStyle(color: Colors.white),),)),
            ],
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Calender()),),
            child: const ListTile(
              leading: Icon(Icons.calendar_month_outlined, color: Colors.white),
              title: Text("Calender", style: TextStyle(color: Colors.white)),
            ),
          ),
          ExpansionTile(
            title: Text("Doctor's Schedule",style: TextStyle(color: Colors.white),),
            leading: Icon(Icons.watch_later, color: Colors.white,),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Doctor_Schedule()),),
                  child: ListTile(title: Text("Rajkot",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Doctor_Schedule()),),
                  child: ListTile(title: Text("Surat",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Doctor_Schedule()),),
                  child: ListTile(title: Text("Ahmedabad",style: TextStyle(color: Colors.white),),))
            ],
          ),
          ExpansionTile(
            leading: Icon(Icons.featured_play_list_outlined, color: Colors.white),
            title: Text("Reports", style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Due_Payment()),),
                  child: ListTile(title: Text("Due Payment",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Staff_Treatment()),),
                  child: ListTile(title: Text("Staff Treatment",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Staff_Rec_Payment()),),
                  child: ListTile(title: Text("Staff Received Payment",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Rev_Rep()),),
                  child: ListTile(title: Text("Revenue Report",style: TextStyle(color: Colors.white),),)),
              ],
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Graph()),),
            child: const ListTile(
              leading: Icon(Icons.auto_graph, color: Colors.white),
              title: Text("Graph", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>S_Holiday()),),
            child: const ListTile(
              leading: Icon(Icons.star, color: Colors.white),
              title: Text("Holidays", style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
