import 'package:flutter/material.dart';
import 'package:therapix_ui/loginPage.dart';
import 'package:therapix_ui/staff/s_drawer.dart';

class S_Dashboard extends StatefulWidget {
  const S_Dashboard({super.key});

  @override
  State<S_Dashboard> createState() => _S_DashboardState();
}

class _S_DashboardState extends State<S_Dashboard> {
  @override
  Widget build(BuildContext context) {
    String? selectedItem;
    String packagedropdownvalue = 'All';
    var package = [
      'All',
      'Ortho',
      'Neuro',
      'Pediatricts',
      'Home Ortho',
      'Home Neuro',
      'Home Pediatricts',
    ];
    String Attendeddropdownvalue = 'All';
    var attended = [
      'All',
      'Yes','NO'
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Dashboard",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Staff Panel",
                child: Text("Staff Panel"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      drawer: S_Drawer(),
      backgroundColor: customColor("#E4E7ED"),
      body: Column(
        children: [
          Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(5)
            ),
            margin: EdgeInsets.all(4),
            padding: EdgeInsets.all(10),
            child: Column(
              children: [
                RichText(text: TextSpan(
                    children: [
                      WidgetSpan(child: Row(
                        mainAxisAlignment:MainAxisAlignment.start ,
                        children: [Text("Today's Appointment ",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                          Text(' With Due Days', style: TextStyle(fontSize: 20,color: Colors.grey),)
                        ],)
                      )
                    ]
                )),
                SizedBox(height: 10,),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Date",
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      width: 72,
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height-825,
                      width: MediaQuery.of(context).size.width-140,
                      child: TextField(
                        decoration: InputDecoration(border: OutlineInputBorder(),
                            hintText: "Select Start Date"),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  children: [
                    Text("Package", style: TextStyle(fontSize: 25,fontWeight: FontWeight.w600),),
                    SizedBox(width: 27,),
                    Container(width: MediaQuery.of(context).size.width-145,
                      decoration: BoxDecoration(
                        border: Border.all(),
                      ),
                      child: DropdownButton(
                          padding: EdgeInsets.all(4),
                          value: packagedropdownvalue,
                          items: package.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:25),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              packagedropdownvalue=newValue!;
                            });
                          }),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  children: [
                    Text("Attended", style: TextStyle(fontSize: 25,fontWeight: FontWeight.w600),),
                    SizedBox(width: 21,),
                    Container(width: MediaQuery.of(context).size.width-145,
                      decoration: BoxDecoration(
                          border: Border.all()
                      ),
                      height: 60,
                      child:DropdownButton(
                          padding: EdgeInsets.all(4),
                          value: Attendeddropdownvalue,
                          items: attended.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:25),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              Attendeddropdownvalue=newValue!;
                            });
                          }),
                    ),
                  ],
                ),
                SizedBox(height: 12,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(onPressed: (){
                      print("abc");
                    },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: customColor("#0F6A8D")
                        ),
                        child: Text("Search",style: TextStyle(color: Colors.white),)
                    ),
                    SizedBox(width: 20,),
                    ElevatedButton(onPressed: (){
                      print("abc");
                    },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red
                        ),
                        child: Text("Clear",style: TextStyle(color: Colors.white),)
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    border: TableBorder.all(color: Colors.black),
                    columns: [
                      DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("PATIENT NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("DUE DAYS", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      ],
                    rows: [
                      DataRow(cells: [
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        ])
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 10,),
          Container(decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(5)
          ),
            padding: EdgeInsets.all(5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 5,),
                Text("Due Amount", style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                SizedBox(height: 10,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    border: TableBorder.all(color: Colors.black),
                    columns: [
                      DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("PATIENT NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("TOTAL", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("PAID", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("DUE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("MAIN STAFF", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("DEPARTMENT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("ACTION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),))
                    ],
                    rows: [
                      DataRow(cells: [
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                        DataCell(Text("-")),
                      ])
                    ],
                  ),
                ),
                SizedBox(height: 10,)
              ],
            ),
          ),
        ],
      ),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
