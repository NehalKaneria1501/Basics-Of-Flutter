import 'package:flutter/material.dart';
import 'package:therapix_ui/loginPage.dart';
import 'package:therapix_ui/staff/s_drawer.dart';

class S_Graph extends StatefulWidget {
  const S_Graph({super.key});

  @override
  State<S_Graph> createState() => _S_GraphState();
}

class _S_GraphState extends State<S_Graph> {
  String? selectedItem;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Graph",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 25,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Staff Panel",
                child: Text("Staff Panel"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      drawer: S_Drawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
