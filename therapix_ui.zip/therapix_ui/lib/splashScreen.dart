import 'dart:async';
import 'package:flutter/material.dart';
import 'package:therapix_ui/loginPage.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState(){
    super.initState();

    Timer(Duration(seconds: 3),(){
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LoginPage(),
      ));
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.cyan[100],
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset("assets/images/TherapixLogo.png"),
              SizedBox(height: 25,),
              Text("WELCOME TO DIGITAL CRM", style: TextStyle(fontSize: 25,color: Colors.cyan[900], fontWeight: FontWeight.bold),)
            ],
          ),
        ),
      ),
    );
  }
}
int customColor(String colorCode){
  String colors= "0xff"+ colorCode ;
  colors=colors.replaceAll("#", "");
  return int.parse(colors);
}