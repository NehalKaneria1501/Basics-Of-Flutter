import 'package:flutter/material.dart';
import 'package:therapix_ui/reception/r_add_patient.dart';
import 'package:therapix_ui/reception/r_dashboard.dart';
import 'package:therapix_ui/reception/r_due_pay.dart';
import 'package:therapix_ui/reception/r_feedback.dart';
import 'package:therapix_ui/reception/r_rev_rep.dart';

class R_Drawer extends StatefulWidget {
  const R_Drawer({super.key});

  @override
  State<R_Drawer> createState() => _R_DrawerState();
}

class _R_DrawerState extends State<R_Drawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: customColor("#0F6A8D"),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              color: customColor("#0F6A8D"),
            ),
            accountName: const Text(
              "Reception Panel",
              style: TextStyle(fontSize: 25),
            ),
            accountEmail: const Text(""),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>R_Dashboard()),),
            child: const ListTile(
              leading: Icon(Icons.home, color: Colors.white),
              title: Text("Dashboard", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>R_New_Patient()),),
            child: const ListTile(
              leading: Icon(Icons.calendar_month_outlined, color: Colors.white),
              title: Text("Add New Patien", style: TextStyle(color: Colors.white)),
            ),
          ),
          ExpansionTile(
            leading: Icon(Icons.featured_play_list_outlined, color: Colors.white),
            title: Text("Reports", style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>R_Rev_Rep()),),
                  child: ListTile(title: Text("Revenue Report",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>R_Due_Pay()),),
                  child: ListTile(title: Text("Due Payment Report",style: TextStyle(color: Colors.white),),)),
              ],
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>R_Feedback()),),
            child: const ListTile(
              leading: Icon(Icons.feedback_outlined, color: Colors.white),
              title: Text("Feedback Form", style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
