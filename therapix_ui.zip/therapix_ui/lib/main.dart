import 'package:flutter/material.dart';
import 'package:therapix_ui/admin/a_add_new_patient.dart';
import 'package:therapix_ui/admin/a_all_patient.dart';
import 'package:therapix_ui/admin/a_bill_report.dart';
import 'package:therapix_ui/admin/a_calender.dart';
import 'package:therapix_ui/admin/a_dashboard.dart';
import 'package:therapix_ui/admin/a_doctor_schedule.dart';
import 'package:therapix_ui/admin/a_due_payment.dart';
import 'package:therapix_ui/admin/a_feedback.dart';
import 'package:therapix_ui/admin/a_graph.dart';
import 'package:therapix_ui/admin/a_holiday.dart';
import 'package:therapix_ui/admin/a_new_patient.dart';
import 'package:therapix_ui/admin/a_rec_payment.dart';
import 'package:therapix_ui/admin/a_ref_person.dart';
import 'package:therapix_ui/admin/a_rev_rep_all.dart';
import 'package:therapix_ui/admin/a_rev_rep_staff.dart';
import 'package:therapix_ui/admin/a_staff_manegment.dart';
import 'package:therapix_ui/admin/a_treatment_rep.dart';
import 'package:therapix_ui/admin/a_treatment_staff.dart';
import 'package:therapix_ui/admin/a_unsettle_patient.dart';
import 'package:therapix_ui/reception/r_add_patient.dart';
import 'package:therapix_ui/reception/r_dashboard.dart';
import 'package:therapix_ui/reception/r_due_pay.dart';
import 'package:therapix_ui/reception/r_feedback.dart';
import 'package:therapix_ui/reception/r_rev_rep.dart';
import 'package:therapix_ui/staff/S_Calender.dart';
import 'package:therapix_ui/staff/S_Doctor_Schedule.dart';
import 'package:therapix_ui/staff/s_add_new_patient.dart';
import 'package:therapix_ui/staff/s_dashboard.dart';
import 'package:therapix_ui/staff/s_due_payment.dart';
import 'package:therapix_ui/staff/s_graph.dart';
import 'package:therapix_ui/staff/s_holiday.dart';
import 'package:therapix_ui/staff/s_rev_rep.dart';
import 'package:therapix_ui/staff/s_staff_rec_pay.dart';
import 'package:therapix_ui/staff/s_staff_treatment.dart';
import 'package:therapix_ui/staff/s_unsettled_patient.dart';
import 'package:therapix_ui/super_admin/assessment_factor.dart';
import 'package:therapix_ui/super_admin/assessment_treatment.dart';
import 'package:therapix_ui/super_admin/bill_report.dart';
import 'package:therapix_ui/super_admin/branch.dart';
import 'package:therapix_ui/super_admin/branch_report.dart';
import 'package:therapix_ui/super_admin/calender.dart';
import 'package:therapix_ui/super_admin/doctorschedule.dart';
import 'package:therapix_ui/super_admin/due_payment_report.dart';
import 'package:therapix_ui/super_admin/feedback_form.dart';
import 'package:therapix_ui/super_admin/graph.dart';
import 'package:therapix_ui/super_admin/holiday.dart';
import 'package:therapix_ui/super_admin/homePage.dart';
import 'package:therapix_ui/super_admin/home_nuero.dart';
import 'package:therapix_ui/super_admin/home_ortho.dart';
import 'package:therapix_ui/super_admin/home_pedia.dart';
import 'package:therapix_ui/loginPage.dart';
import 'package:therapix_ui/super_admin/add_new_patient.dart';
import 'package:therapix_ui/super_admin/neuro_package.dart';
import 'package:therapix_ui/super_admin/new_patient_report.dart';
import 'package:therapix_ui/super_admin/ortho_package.dart';
import 'package:therapix_ui/super_admin/panel.dart';
import 'package:therapix_ui/super_admin/pediatric_package.dart';
import 'package:therapix_ui/super_admin/referral_person.dart';
import 'package:therapix_ui/super_admin/referral_report.dart';
import 'package:therapix_ui/super_admin/rev_rep_date.dart';
import 'package:therapix_ui/super_admin/rev_rep_dept.dart';
import 'package:therapix_ui/super_admin/rev_rep_staff.dart';
import 'package:therapix_ui/super_admin/rules.dart';
import 'package:therapix_ui/super_admin/setting.dart';
import 'package:therapix_ui/splashScreen.dart';
import 'package:therapix_ui/super_admin/staff_management.dart';
import 'package:therapix_ui/super_admin/time_schedule.dart';
import 'package:therapix_ui/super_admin/treatment_rep_staff.dart';
import 'package:therapix_ui/super_admin/treatment_report_dept.dart';
import 'package:therapix_ui/super_admin/unsettled_patient.dart';

import 'super_admin/all_patient.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home:Panel(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
       title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
