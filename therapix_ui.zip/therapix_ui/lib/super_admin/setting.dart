import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/drawer_code.dart';
import 'package:therapix_ui/loginPage.dart';

class Setting extends StatefulWidget {
  const Setting({super.key});
  @override
  State<Setting> createState() => _SettingState();
}

class _SettingState extends State<Setting> {
  String? selectedItem;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Setting",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 25,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Shailesh Kagathara",
                child: Text("Shailesh Kagathara"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("183600",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Total Provide SMS",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("183600",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Total Provide SMS",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("9",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Used SMS",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("991",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Remaing SMS",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("5",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Used In Attendance",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("3",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Used In Add Patient",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("1",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Used In Refer By",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(right: 15),
                height: 100,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("1",style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
                    Text("Used In Birthdat Wish",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 20),),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      drawer: MyDrawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
