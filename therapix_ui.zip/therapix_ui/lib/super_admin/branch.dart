import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/drawer_code.dart';
import 'package:therapix_ui/loginPage.dart';

class Branch extends StatefulWidget {
  const Branch({super.key});
  @override
  State<Branch> createState() => _BranchState();
}

class _BranchState extends State<Branch> {
  String? selectedItem;
  String dropdownvalue = '10';
  var items = [
    '10',
    '20',
    '50',
    '100',
    'All'
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Branch",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 25,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Shailesh Kagathara",
                child: Text("Shailesh Kagathara"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.all(4),
            padding: EdgeInsets.all(4),
            color: Colors.white,
            child: Column(
              children: [
                SizedBox(height: 10,),
                Row(
                  children: [
                    SizedBox(width: 10,),
                    Text("Branch List",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 25),),
                    SizedBox(width: 150,),
                    ElevatedButton(onPressed: (){
                      print("new");
                    }, style: ElevatedButton.styleFrom(
                        backgroundColor: customColor("#0F6A8D")
                    ),child: Text(
                      "+ New" , style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.white),
                    )
                    )
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    DropdownButton(
                      value: dropdownvalue,
                      items: items.map((String items){
                        return DropdownMenuItem(
                          value: items,
                          child: Text(
                            items, style: TextStyle(fontSize: 30),
                          ),);
                      }).toList(),
                      onChanged: (String? newValue){
                        setState(() {
                          dropdownvalue= newValue!;
                        });
                      },
                    )
                  ],
                ),
                SizedBox(height: 10,),
                SizedBox(
                  height: MediaQuery.of(context).size.height-800,
                  width: MediaQuery.of(context).size.width-120,
                  child: TextField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "Search ",
                    ),
                  ),
                ),
                SizedBox(height: 10,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                      dataRowMaxHeight: double.infinity,
                      border: TableBorder.all(color: Colors.black),
                      columns: [
                        DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("ACTION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("CITY", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("ADDRESS", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("PERSON", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("CONTACT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("EMAIL", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      ],
                      rows: const [
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("button")),
                          DataCell(Text("Dixit Dobariya")),
                          DataCell(Text("Rajkot")),
                          DataCell(Text("Rajkot")),
                          DataCell(Text("Dr Shailesh Kagathara")),
                          DataCell(Text("9999999999")),
                          DataCell(Text("user@gmail.com")),
                        ],),
                      ]),
                ),
                SizedBox(height: 20,),
              ],
            ),
          ),
        ],
      ),
      drawer: MyDrawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}