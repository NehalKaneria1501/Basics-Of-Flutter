import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/drawer_code.dart';
import 'package:therapix_ui/loginPage.dart';

class Home_Pedia extends StatefulWidget {
  const Home_Pedia({super.key});
  @override
  State<Home_Pedia> createState() => _Home_PediaState();
}

class _Home_PediaState extends State<Home_Pedia> {
  String? selectedItem;
  String dropdownvalue = '10';
  var items = [
    '10',
    '20',
    '50',
    'All'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Home Pediatrics",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Shailesh Kagathara",
                child: Text("Shailesh Kagathara"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(4),
              padding: EdgeInsets.all(4),
              color: Colors.white,
              child: Column(
                children: [
                  Row(
                    children: [
                      SizedBox(width: 5,),
                      Text("Home Pedia List", style: TextStyle(fontSize: 30,fontWeight: FontWeight.w700,),),
                      SizedBox(width: 10,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("+ New",style: TextStyle(color: Colors.white),)
                      ),
                      SizedBox(width: 3,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("+ Days",style: TextStyle(color: Colors.white),)
                      ),
                    ],
                  ),
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      DropdownButton(
                          value: dropdownvalue,
                          items: items.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:30),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              dropdownvalue=newValue!;
                            });
                          }),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height-800,
                    width: MediaQuery.of(context).size.width-120,
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Search ",
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      border: TableBorder.all(color: Colors.black),
                      columns: [
                        DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("ACTION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("1 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("5 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("10 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("15 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("20 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("25 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("30 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("60 Day Charge", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      ],
                      rows: [
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("button")),
                          DataCell(Text("Dixit Dobariya")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                        ],),
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("button")),
                          DataCell(Text("Dixit Dobariya")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                        ],),
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("button")),
                          DataCell(Text("Dixit Dobariya")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                        ],),
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("button")),
                          DataCell(Text("Dixit Dobariya")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                        ],),
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("button")),
                          DataCell(Text("Dixit Dobariya")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                          DataCell(Text("0")),
                        ],),
                      ],
                    ),
                  ),
                  SizedBox(height: 10,),
                ],
              ),
            )
          ],
        ),
      ),
      drawer: MyDrawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
