import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/add_new_patient.dart';
import 'package:therapix_ui/super_admin/all_patient.dart';
import 'package:therapix_ui/super_admin/assessment_factor.dart';
import 'package:therapix_ui/super_admin/assessment_treatment.dart';
import 'package:therapix_ui/super_admin/bill_report.dart';
import 'package:therapix_ui/super_admin/branch.dart';
import 'package:therapix_ui/super_admin/branch_report.dart';
import 'package:therapix_ui/super_admin/calender.dart';
import 'package:therapix_ui/super_admin/doctorschedule.dart';
import 'package:therapix_ui/super_admin/due_payment_report.dart';
import 'package:therapix_ui/super_admin/feedback_form.dart';
import 'package:therapix_ui/super_admin/graph.dart';
import 'package:therapix_ui/super_admin/holiday.dart';
import 'package:therapix_ui/super_admin/home_nuero.dart';
import 'package:therapix_ui/super_admin/home_ortho.dart';
import 'package:therapix_ui/super_admin/home_pedia.dart';
import 'package:therapix_ui/super_admin/neuro_package.dart';
import 'package:therapix_ui/super_admin/new_patient_report.dart';
import 'package:therapix_ui/super_admin/ortho_package.dart';
import 'package:therapix_ui/super_admin/panel.dart';
import 'package:therapix_ui/super_admin/pediatric_package.dart';
import 'package:therapix_ui/super_admin/referral_person.dart';
import 'package:therapix_ui/super_admin/referral_report.dart';
import 'package:therapix_ui/super_admin/rev_rep_date.dart';
import 'package:therapix_ui/super_admin/rev_rep_dept.dart';
import 'package:therapix_ui/super_admin/rev_rep_staff.dart';
import 'package:therapix_ui/super_admin/rules.dart';
import 'package:therapix_ui/super_admin/setting.dart';
import 'package:therapix_ui/super_admin/staff_management.dart';
import 'package:therapix_ui/super_admin/time_schedule.dart';
import 'package:therapix_ui/super_admin/treatment_rep_staff.dart';
import 'package:therapix_ui/super_admin/treatment_report_dept.dart';
import 'package:therapix_ui/super_admin/unsettled_patient.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: customColor("#0F6A8D"),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              color: customColor("#0F6A8D"),
            ),
            accountName: const Text(
              "Shailesh Kagathara",
              style: TextStyle(fontSize: 25),
            ),
            accountEmail: const Text(""),
          ),
          ExpansionTile(
            title: Text("Dashboard",style: TextStyle(color: Colors.white),),
            leading: Icon(Icons.home,color: Colors.white,),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Panel()),),
                  child: ListTile(title: Text("Rajkot",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Panel()),),
                  child: ListTile(title: Text("Surat",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Panel()),),
                  child: ListTile(title: Text("Ahmedabad",style: TextStyle(color: Colors.white),),))
            ],
          ),
          ExpansionTile(
            leading: Icon(Icons.person, color: Colors.white),
            title: Text("Patient", style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Unsettled_patient()),),
                  child: ListTile(title: Text("Unsettled Patient",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>All_patient()),),
                  child: ListTile(title: Text("All Patient",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>New_patient()),),
                  child: ListTile(title: Text("Add New Patient",style: TextStyle(color: Colors.white),),)),
            ],
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Calender()),),
            child: const ListTile(
              leading: Icon(Icons.calendar_month_outlined, color: Colors.white),
              title: Text("Calender", style: TextStyle(color: Colors.white)),
            ),
          ),
          // buildExpansionTile("Doctors Schedule", Icons.watch_later, ["Rajkot", "Surat", "Ahmedabad"]),
          ExpansionTile(
            title: Text("Doctor's Schedule",style: TextStyle(color: Colors.white),),
            leading: Icon(Icons.watch_later, color: Colors.white,),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Doctor_Schedule()),),
                  child: ListTile(title: Text("Rajkot",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Doctor_Schedule()),),
                  child: ListTile(title: Text("Surat",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Doctor_Schedule()),),
                  child: ListTile(title: Text("Ahmedabad",style: TextStyle(color: Colors.white),),))
            ],
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Time_Schedule()),),
            child: const ListTile(
              leading: Icon(Icons.watch_later, color: Colors.white),
              title: Text("Time Schedule", style: TextStyle(color: Colors.white)),
            ),
          ),
          ExpansionTile(
            leading: Icon(Icons.featured_play_list_outlined, color: Colors.white),
            title: Text("Reports", style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Revenue_Rep_Date()),),
                  child: ListTile(title: Text("Revenue Report-Date",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Rev_Rev_Staff()),),
                  child: ListTile(title: Text("Revenue Report-Staff",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Rev_Rev_Dept()),),
                  child: ListTile(title: Text("Revenue Report-Department",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Due_Payment()),),
                  child: ListTile(title: Text("Due Payment Report",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>New_Patien_Report()),),
                  child: ListTile(title: Text("New Patient Report",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Treatment_Report_Dept()),),
                  child: ListTile(title: Text("Treatment Report Department",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Treatment_Rep_Staff()),),
                  child: ListTile(title: Text("Treatment Report Staff",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Referral_Report()),),
                  child: ListTile(title: Text("Referral Report",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Branch_Report()),),
                  child: ListTile(title: Text("Branch Report",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Bill_Report()),),
                  child: ListTile(title: Text("Bill Report",style: TextStyle(color: Colors.white),),)),
            ],
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Referral_Person()),),
            child: const ListTile(
              leading: Icon(Icons.chat, color: Colors.white),
              title: Text("Referral Person", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Graph()),),
            child: const ListTile(
              leading: Icon(Icons.auto_graph, color: Colors.white),
              title: Text("Graph", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Staff_Management()),),
            child: const ListTile(
              leading: Icon(Icons.person, color: Colors.white),
              title: Text("Staff Management", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Branch()),),
            child: const ListTile(
              leading: Icon(CupertinoIcons.building_2_fill, color: Colors.white),
              title: Text("Branches", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Holiday()),),
            child: const ListTile(
              leading: Icon(Icons.star, color: Colors.white),
              title: Text("Holidays", style: TextStyle(color: Colors.white)),
            ),
          ),
          ExpansionTile(
            title: Text("Packages",style: TextStyle(color: Colors.white)),
            leading: Icon(Icons.card_giftcard,color: Colors.white),
            trailing: Icon(Icons.keyboard_arrow_down, color: Colors.white),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Ortho_Package()),),
                  child: ListTile(title: Text("Ortho",style: TextStyle(color: Colors.white)))),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Nuero_Package()),),
                  child: ListTile(title: Text("Neuro",style: TextStyle(color: Colors.white)))),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Pediatric_Package()),),
                  child: ListTile(title: Text("Paediatrics", style: TextStyle(color: Colors.white)))),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Home_Ortho()),),
                  child: ListTile(title: Text("Home Ortho",style: TextStyle(color: Colors.white)))),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Home_Nuero()),),
                  child: ListTile(title: Text("Home Neuro",style: TextStyle(color: Colors.white)))),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Home_Pedia()),),
                  child: ListTile(title: Text("Home Paediatrics", style: TextStyle(color: Colors.white)))),
            ],
          ),
          ExpansionTile(
            title: Text("Assessment Form Modification",style: TextStyle(color: Colors.white),),
            leading: Icon(Icons.edit,color: Colors.white,),
            trailing: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
            children: [
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Assessment_Factor()),),
                  child: ListTile(title: Text("Assessment Factor",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Rules()),),
                  child: ListTile(title: Text("Rules",style: TextStyle(color: Colors.white),),)),
              InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Assessment_treatment()),),
                  child: ListTile(title: Text("Assessment Treatment",style: TextStyle(color: Colors.white)),))
            ],
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Feedback_Form()),),
            child: const ListTile(
              leading: Icon(Icons.feedback_outlined, color: Colors.white),
              title: Text("Feedback Form", style: TextStyle(color: Colors.white)),
            ),
          ),
          InkWell(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Setting()),),
            child: const ListTile(
              leading: Icon(Icons.settings, color: Colors.white),
              title: Text("Settings", style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
