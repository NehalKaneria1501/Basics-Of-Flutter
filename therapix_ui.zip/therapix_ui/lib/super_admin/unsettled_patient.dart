import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/drawer_code.dart';
import 'package:therapix_ui/loginPage.dart';

class Unsettled_patient extends StatefulWidget {
  const Unsettled_patient({super.key});
  @override
  State<Unsettled_patient> createState() => _Unsettled_patientState();
}

class _Unsettled_patientState extends State<Unsettled_patient> {
  String? selectedItem;
  String dropdownvalue = '10';
  var items = [
    '10',
    '20',
    '50',
    'All'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Unsettled Patient",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Shailesh Kagathara",
                child: Text("Shailesh Kagathara"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
            Container(
              margin: EdgeInsets.all(4),
              padding: EdgeInsets.all(4),
              color: Colors.white,
              child: Column(
                children: [
                  Row(
                    children: [
                      SizedBox(width: 5,),
                      Text("Patient List", style: TextStyle(fontSize: 30,fontWeight: FontWeight.w700,),),
                      SizedBox(width: 50,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("Search",style: TextStyle(color: Colors.white),)
                      ),
                      SizedBox(width: 10,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("+ New",style: TextStyle(color: Colors.white),)
                      ),
                    ],
                  ),
                  SizedBox(height: 15,),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        "Search",
                        style: TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: 12,
                      ),
                      SizedBox(
                       height: MediaQuery.of(context).size.height-825,
                        width: MediaQuery.of(context).size.width-100,
                        child: TextField(
                          decoration: InputDecoration(border: OutlineInputBorder(),
                          hintText: "Search Patient"),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("Search",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)
                      ),
                      SizedBox(width: 20,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red
                          ),
                          child: Text("Clear",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      DropdownButton(
                          value: dropdownvalue,
                          items: items.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:30),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              dropdownvalue=newValue!;
                            });
                          }),
                    ],
                  ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height-800,
                        width: MediaQuery.of(context).size.width-120,
                        child: TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            hintText: "Search ",
                          ),
                        ),
                      ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      border: TableBorder.all(color: Colors.black),
                      columns: [

                        DataColumn(label: Text("#",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("NAME",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("EARNED",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("DISCOUNT",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("RECEIVED",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("DUE AMOUNT",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("TOTAL PATIENT",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        DataColumn(label: Text("ATTENED TREATMENT",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),))
                      ],
                      rows: [
                        DataRow(cells: [
                          DataCell(Text("1")),
                          DataCell(Text("Rajkot")),
                          DataCell(Text("123")),
                          DataCell(Text("123")),
                          DataCell(Text("123")),
                          DataCell(Text("123")),
                          DataCell(Text("123")),
                          DataCell(Text("123")),
                        ])
                      ],
                    ),
                  ),
                  SizedBox(height: 10,),
                ],
              ),
            )
        ],
      ),
      drawer: MyDrawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
