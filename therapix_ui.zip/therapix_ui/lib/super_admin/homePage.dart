import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:therapix_ui/super_admin/assessment_factor.dart';
import 'package:therapix_ui/super_admin/assessment_treatment.dart';
import 'package:therapix_ui/super_admin/branch.dart';
import 'package:therapix_ui/super_admin/doctorschedule.dart';
import 'package:therapix_ui/super_admin/drawer_code.dart';
import 'package:therapix_ui/super_admin/holiday.dart';
import 'package:therapix_ui/super_admin/home_nuero.dart';
import 'package:therapix_ui/super_admin/home_ortho.dart';
import 'package:therapix_ui/super_admin/home_pedia.dart';
import 'package:therapix_ui/loginPage.dart';
import 'package:therapix_ui/super_admin/neuro_package.dart';
import 'package:therapix_ui/super_admin/ortho_package.dart';
import 'package:therapix_ui/super_admin/panel.dart';
import 'package:therapix_ui/super_admin/pediatric_package.dart';
import 'package:therapix_ui/super_admin/referral_person.dart';
import 'package:therapix_ui/super_admin/rules.dart';
import 'package:therapix_ui/super_admin/setting.dart';
import 'package:therapix_ui/splashScreen.dart';
import 'package:therapix_ui/super_admin/staff_management.dart';
import 'package:therapix_ui/super_admin/time_schedule.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? selectedItem;

  String dropdownvalue = '10';

  var items = [
    '10',
    '20',
    '50',
    'All'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Branch",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
              else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Shailesh Kagathara",
                child: Text("Shailesh Kagathara"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      drawer: MyDrawer(),
      backgroundColor: customColor("#E4E7ED"),
      body: Column(
        children: [
          const SizedBox(height: 8),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Panel()),),
            child: Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(left: 15),
                height: 90,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  children: [
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        SizedBox(width:10),
                        Icon(Icons.home_work_sharp,color: Colors.grey,size: 35,),
                        SizedBox(width:10 ,),
                        Text("Rajkot Branch",style: TextStyle(color: Colors.black,fontSize: 25, fontWeight: FontWeight.bold),)
                      ],
                    ),
                    Divider(height: 2,color: Colors.grey,indent: 25, endIndent: 25,),
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        SizedBox(width:15),
                        Icon(Icons.arrow_forward,color: Colors.grey,),
                        SizedBox(width:18),
                        Text("View Admin Panel",style: TextStyle(color: Colors.grey[800],fontSize: 20),)
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Panel()),),
            child: Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(left: 15),
                height: 90,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  children: [
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        SizedBox(width:10),
                        Icon(Icons.home_work_sharp,color: Colors.grey,size: 35,),
                        SizedBox(width:10 ,),
                        Text("Surat Branch",style: TextStyle(color: Colors.black,fontSize: 25, fontWeight: FontWeight.bold),)
                      ],
                    ),
                    Divider(height: 2,color: Colors.grey,indent: 25, endIndent: 25,),
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        SizedBox(width:15),
                        Icon(Icons.arrow_forward,color: Colors.grey,),
                        SizedBox(width:18),
                        Text("View Admin Panel",style: TextStyle(color: Colors.grey[800],fontSize: 20),)
                      ],
                    ),
                    SizedBox(height: 5,)
                  ],
                ),
              ),
            ),
          ),
          InkWell(
            onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>Panel()),),
            child: Card(
              elevation: 5,
              color: Colors.white,
              shadowColor: Colors.grey,
              child: Container(
                padding: EdgeInsets.only(left: 15),
                height: 90,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  children: [
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        SizedBox(width:10),
                        Icon(Icons.home_work_sharp,color: Colors.grey,size: 35,),
                        SizedBox(width:10 ,),
                        Text("Ahmedabad Branch",style: TextStyle(color: Colors.black,fontSize: 25, fontWeight: FontWeight.bold),)
                      ],
                    ),
                    Divider(height: 2,color: Colors.grey,indent: 25, endIndent: 25,),
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        SizedBox(width:15),
                        Icon(Icons.arrow_forward,color: Colors.grey,),
                        SizedBox(width:18),
                        Text("View Admin Panel",style: TextStyle(color: Colors.grey[800],fontSize: 20),)
                      ],
                    ),
                    SizedBox(height: 5,)
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: 10,),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              padding: EdgeInsets.all(8),
              width: double.infinity,
              color: Colors.white,
              child: Column(
                children: [
                  RichText(text: TextSpan(
                    children: [
                      WidgetSpan(child: Row(
                        mainAxisAlignment:MainAxisAlignment.start ,
                        children: [Text("Branch Revennue ",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
                        Text(' Current Month', style: TextStyle(fontSize: 20,color: Colors.grey),)
                        ],))
                    ]
                  )),
                  DropdownButton(
                    value: dropdownvalue,
                      items: items.map((String items){
                    return DropdownMenuItem(
                      value: items,
                      child: Text(items),
                    );
                  }).toList(),
                      onChanged: (String? newValue){
                    setState(() {
                      dropdownvalue=newValue!;
                    });
                  }),
                SizedBox(
                  height: 75,
                  width: 300,
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Search...",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    border: TableBorder.all(color: Colors.black),
                    columns: [
                      DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("EARNED", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("DISCOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("RECEIVED", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("DUE AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("TOTAL PATIENT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                      DataColumn(label: Text("ATTENED TREATMENT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),))
                    ], 
                    rows: [
                      DataRow(cells: [
                        DataCell(Text("1")),
                        DataCell(Text("Rajkot")),
                        DataCell(Text("123")),
                        DataCell(Text("123")),
                        DataCell(Text("123")),
                        DataCell(Text("123")),
                        DataCell(Text("123")),
                        DataCell(Text("123")),
                      ])
                    ],
                  ),
                )  
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
