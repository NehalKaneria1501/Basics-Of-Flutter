import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/drawer_code.dart';
import 'package:therapix_ui/loginPage.dart';

class Rev_Payment extends StatefulWidget {
  const Rev_Payment({super.key});

  @override
  State<Rev_Payment> createState() => _Rev_PaymentState();
}

class _Rev_PaymentState extends State<Rev_Payment> {

  String? selectedItem;

  String dropdownvalue = '10';
  var items = [
    '10',
    '20',
    '50',
    '100',
    'All'
  ];

  String staffdropdownvalue = 'Select Staff';
  var staff = [
    'Select Staff',
    'Shalesh Kagathara',
    'Ashok Mer',
    'Pratik Gohil',
  ];

  String departmentdropdownvalue = 'Select Department';
  var department = [
    'Select Department',
    'Ortho',
    'Paediatric',
    'Neuro',
    'Home Ortho',
    'Home Paediatric',
    'Home Neuro'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
      backgroundColor: customColor("#0F6A8D"),
      title: const Text(
        "Revenue Report By Staff",
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w500,
          fontSize: 25,
        ),
      ),
      iconTheme: const IconThemeData(color: Colors.white),
      actions: [
        PopupMenuButton<String>(
          icon: const Icon(Icons.person, color: Colors.white),
          onSelected: (String value) {
            setState(() {
              selectedItem = value;
            });
            if (value == "Sign Out") {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginPage()),
              );
            }else if(value == "Change Password"){
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginPage()),
              );
            }
          },
          itemBuilder: (BuildContext context) => [
            const PopupMenuItem<String>(
              value: "Shailesh Kagathara",
              child: Text("Shailesh Kagathara"),
            ),
            const PopupMenuItem<String>(
              value: "Change Password",
              child: Text("Change Password"),
            ),
            const PopupMenuItem<String>(
              value: "Sign Out",
              child: Text("Sign Out"),
            ),
          ],
        ),
      ],
    ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(4),
              padding: EdgeInsets.all(4),
              color: Colors.white,
              child: Column(
                children: [
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text("Start Date",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                      SizedBox(width: 20,),
                      SizedBox(
                        height: MediaQuery.of(context).size.height/22,
                        width: MediaQuery.of(context).size.width-125,
                        child: TextField(
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: "Enter Start Date"
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text("End Date",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                      SizedBox(width: 27,),
                      SizedBox(
                        height: MediaQuery.of(context).size.height/22,
                        width: MediaQuery.of(context).size.width-125,
                        child: TextField(
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: "Enter End Date"
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text("Staff",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                      SizedBox(width: 55,),
                      SizedBox(

                        width: 275,
                        child: DropdownButton(
                          padding: EdgeInsets.all(4),
                          value: staffdropdownvalue,
                          items: staff.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:20),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              staffdropdownvalue= newValue!;
                            });
                          },
                        ),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Text("Department",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                      SizedBox(width: 1,),
                      SizedBox(
                        width: 275,
                        child: DropdownButton(
                          padding: EdgeInsets.all(4),
                          value: departmentdropdownvalue,
                          items: department.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:20),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              departmentdropdownvalue= newValue!;
                            });
                          },
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("Search",style: TextStyle(color: Colors.white),)
                      ),
                      SizedBox(width: 10,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red
                          ),
                          child: Text("Clear",style: TextStyle(color: Colors.white),)
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("Copy",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("Excel",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("CSV",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("PDF",style: TextStyle(color: Colors.black),)
                      ),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[300]
                          ),
                          child: Text("Print",style: TextStyle(color: Colors.black),)
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      DropdownButton(
                          value: dropdownvalue,
                          items: items.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:30),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              dropdownvalue=newValue!;
                            });
                          }),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height-800,
                    width: MediaQuery.of(context).size.width-120,
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Search ",
                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                        dataRowMaxHeight: double.infinity,
                        border: TableBorder.all(color: Colors.black),
                        columns: [
                          DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("PATIENT NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DUE AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DATE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DEPARTMENT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("PACKAGE NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DAYS", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("DISCOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("FINAL AMOUNT", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("RECEIVED", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("MAIN STAFF", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("SUPPORTED STAFF", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("IS SETTLE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        ],
                        rows: const [
                          DataRow(cells: [
                            DataCell(Text("1")),
                            DataCell(Text("Dixit Dobariya")),
                            DataCell(Text("4800")),
                            DataCell(Text("26-09-2024")),
                            DataCell(Text("Nuero")),
                            DataCell(Text("Nuero Rehabilitation")),
                            DataCell(Text("10")),
                            DataCell(Text("4800")),
                            DataCell(Text("0")),
                            DataCell(Text("4800")),
                            DataCell(Text("0")),
                            DataCell(Text("Dr Pratik Gohil")),
                            DataCell(Text(" ")),
                            DataCell(Text("Not Settled")),
                          ],),
                        ]),
                  )
                ],
              ),
            )
          ],
        ),
      ),
      drawer: MyDrawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
