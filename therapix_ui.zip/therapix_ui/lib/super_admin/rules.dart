import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:therapix_ui/super_admin/drawer_code.dart';
import 'package:therapix_ui/loginPage.dart';

class Rules extends StatefulWidget {
  const Rules({super.key});

  @override
  State<Rules> createState() => _RulesState();
}

class _RulesState extends State<Rules> {
  String? selectedItem;
  String dropdownvalue = '10';
  var items = [
    '10',
    '20',
    '50',
    'All'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColor("#0F6A8D"),
        title: const Text(
          "Form Modification",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 30,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.person, color: Colors.white),
            onSelected: (String value) {
              setState(() {
                selectedItem = value;
              });
              if (value == "Sign Out") {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }else if(value == "Change Password"){
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: "Shailesh Kagathara",
                child: Text("Shailesh Kagathara"),
              ),
              const PopupMenuItem<String>(
                value: "Change Password",
                child: Text("Change Password"),
              ),
              const PopupMenuItem<String>(
                value: "Sign Out",
                child: Text("Sign Out"),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(4),
              padding: EdgeInsets.all(4),
              color: Colors.white,
              child: Column(
                children: [
                  Row(
                    children: [
                      SizedBox(width: 5,),
                      Text(" Add Rules", style: TextStyle(fontSize: 30,fontWeight: FontWeight.w700,),),
                      SizedBox(width: 150,),
                      ElevatedButton(onPressed: (){
                        print("abc");
                      },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: customColor("#0F6A8D")
                          ),
                          child: Text("+ New",style: TextStyle(color: Colors.white),)
                      ),
                    ],
                  ),
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      DropdownButton(
                          value: dropdownvalue,
                          items: items.map((String items){
                            return DropdownMenuItem(
                              value: items,
                              child: Text(items,style:TextStyle(fontSize:30),),
                            );
                          }).toList(),
                          onChanged: (String? newValue){
                            setState(() {
                              dropdownvalue=newValue!;
                            });
                          }),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height-800,
                    width: MediaQuery.of(context).size.width-120,
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Search ",
                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                        dataRowMaxHeight: double.infinity,
                        border: TableBorder.all(color: Colors.black),
                        columns: [
                          DataColumn(label: Text("#", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("ACTION", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("TITLE", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                          DataColumn(label: Text("NAME", style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
                        ],
                        rows: const [
                          DataRow(cells: [
                            DataCell(Text("1")),
                            DataCell(Text("button")),
                            DataCell(Text("Rules")),
                            DataCell(Text("તમને આપવામાં આવેલું પેકેજ એ રેગ્યુલર આવતા દર્દીઓ માટે જ છે. \n નક્કી કરેલ દિવસોમાં વધુમાં વધુ 5 દિવસ ની રજાઓ માન્ય થશે\n આનાથી વધારે દિવસો ની રજાઓ હશે તો પેકેજ લંબાવી શકાશે નહિ.\n પેકેજનો ચાર્જ પૂરેપૂરો એડવાન્સમાં આપવાનો રહેશે. \nપેકેજનો ચાર્જ કોઈપણ સંજોગોમાં રિફંડ નહિ કરી શકાય.\n નિયત કરેલા સમય પ્રમાણે જ આવવાનું રહેશે. \nજો સમય બદલવો હોય તો અગાઉથી જાણ કરવી."
                            )),
                          ],),
                          DataRow(cells: [
                            DataCell(Text("2")),
                            DataCell(Text("button")),
                            DataCell(Text("Back Pain Care")),
                            DataCell(Text("સૂઈને બેસતી વખતે પડખું ફરીને બેઠાં થવું.\nકમરમાંથી વાંકા ન વળવું.\n નીચેથી વસ્તુ લેતી વખતે કમરને બદલે ગોઠણથી વળવું.\n વજન ન ઊંચકવો ઓછો ઉંચકવો.\nનીચે ન બેસવું.\n પલાઠી વાળીને ન બેસવું.\nબેસતી વખતે કમરને સપોર્ટ મળે એ રીતે ટટ્ટાર બેસવું.\nલાંબો સમય મુસાફરી કરવાનું ટાળવું.\nઊભા રહીને કામ કરતી વખતે એક પગ ફૂટરેસ્ટ ઉપર રાખવો.\nફિઝિયોથેરાપિસ્ટની સલાહ પ્રમાણે કસરત કરવી."
                            )),
                          ],),
                          DataRow(
                            cells: [
                            DataCell(Text("1")),
                            DataCell(Text("button")),
                            DataCell(Text("Neck Pain Care")),
                            DataCell(Text("સૂતી વખતે માથા નીચે પાતળુ ઓશિકું રાખવું અથવા ન રાખવું.\nટટ્ટાર બેસવાની ટેવ પાડવી.\nનીચે જોઈને લાંબા સમય સુધી કામ કરવું નહીં.\nકોઇપણ પ્રકાર નું વજન માથા પર ઉચકવું નહિ.\nવાહન ચલાવતી વખતે બને તેટલા ઓછાં આંચકા આવવા જોઇએ.\n મોબાઈલ કમ્પ્યૂટર નો ઉપયોગ લાંબો સમય ના કરવો.\nકામ કરતી વખતે વચ્ચે બ્રેક લેવો."
                            )),
                          ],),
                          DataRow(cells: [
                            DataCell(Text("1")),
                            DataCell(Text("button")),
                            DataCell(Text("Knee Pain Care")),
                            DataCell(Text("પલાઠી વાળીને બેસવું નહીં.\n નીચે ન બેસવું.\nઇન્ડિયન ટોઇલેટ નો ઉપયોગ કરવાનું ટાળવું.\n પગથિયાં ચડ ઉતર કરવા નહીં.\n લાંબો સમય ઊભા રહેવું નહીં.\n શરીરનું વજન કન્ટ્રોલ માં રાખવું.\nનિયમીત કસરત કરવી."
                            )),
                          ],),
                    ]),
                  )
                ],
              ),
            )
          ],
        ),
      ),
      drawer: MyDrawer(),
      backgroundColor: customColor("#E4E7ED"),
    );
  }
  Color customColor(String colorCode) {
    final hexCode = colorCode.replaceAll("#", "");
    return Color(int.parse("0xFF$hexCode"));
  }
}
