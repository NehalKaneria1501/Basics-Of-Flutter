import 'package:flutter/material.dart';

class HourlyForecastItem extends StatefulWidget {
  final IconData icon;
  final String time;
  final String temperature;

  const HourlyForecastItem({
    Key? key,
    required this.icon,
    required this.time,
    required this.temperature,
  }) : super(key: key);

  @override
  State<HourlyForecastItem> createState() => _HourlyForecastItemState();
}

class _HourlyForecastItemState extends State<HourlyForecastItem> {
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              widget.time,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Icon(widget.icon, size: 32),
            const SizedBox(height: 8),
            Text(
              widget.temperature,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
