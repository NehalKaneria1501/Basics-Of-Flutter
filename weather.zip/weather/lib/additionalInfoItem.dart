import 'package:flutter/material.dart';

class Additionalinfoitem extends StatefulWidget {
  final IconData icon;
  final String label;
  final String value;

  const Additionalinfoitem({
    Key? key,
    required this.icon,
    required this.label,
    required this.value,
  }) : super(key: key);

  @override
  State<Additionalinfoitem> createState() => _AdditionalInfoItemState();
}

class _AdditionalInfoItemState extends State<Additionalinfoitem> {
  IconData? get icon => null;

  String? get value => null;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, size: 32),
        SizedBox(height: 8),
        Text('label'),
        SizedBox(height: 8),
        Text(
          value!,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
