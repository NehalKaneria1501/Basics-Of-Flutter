import 'package:flutter/material.dart';

class Stacking extends StatefulWidget {
  const Stacking({super.key});

  @override
  State<Stacking> createState() => _StackingState();
}

class _StackingState extends State<Stacking> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Fifa"),
        actions: [Icon(Icons.stacked_bar_chart_outlined)],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: Stack(
            fit: StackFit.passthrough,
            children:  [
              Positioned(
              child: Container(
                height: 250,
                width: 450,
                color: Colors.green,
                child: Center(
                  child:Text('Top Widget',
                    style: TextStyle(color: Colors.white,
                        fontSize: 20,),
                    textAlign: TextAlign.justify,
                  ),
                ),
              ),
                left: 1,
              ),
              Positioned(
                  child:Center(
                    child: Container(
                      height: 210,
                    width: 450,
                    color: Colors.blue,
                    child: Center(
                    child: Text('Middle Widget',
                    style: TextStyle(color: Colors.white,fontSize: 20),),
                                ),
                                ),
                  ),
                left: 10,
                bottom: 507,
                right: 10,
              ),
              Positioned(
                  child: Container(
                    height: 180,
                    width: 450,
                    color: Colors.orange,
                    child: Center(
                      child: Text('Bottom Widget',
                        style: TextStyle(color: Colors.white,fontSize: 20),),
                    ),
                  ),
                top: 20,
                left: 25,
                right: 25,
              ),
              Positioned(
                  child: Container(
                    height: 150,
                    width: 450,
                    color: Colors.yellow,
                    child: Center(
                      child: Text('Center Widget',
                      style: TextStyle(color: Colors.white,fontSize: 20),),
                    ),
                  ),
                top:30,
                left: 35,
                right: 35,
              ),

          ],
        ),
              ),
      ),
    );
  }
}