import 'package:flutter/material.dart';

class Stackoverflow extends StatefulWidget {
  const Stackoverflow({super.key});

  @override
  State<Stackoverflow> createState() => _StackoverflowState();
}

class _StackoverflowState extends State<Stackoverflow> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Nba"),
        actions: [Icon(Icons.stacked_bar_chart_outlined)],
      ),
    body: SingleChildScrollView(
    child: Center(
    child: Stack(
    fit: StackFit.passthrough,
    children: <Widget> [
      IndexedStack(
        index: 1,
        children: <Widget> [
          Container(
            height: 100,
            width: 100,
            color: Colors.green,
            child: Center(
              child: Text('First Widget',
                style: TextStyle(color: Colors.black,fontSize: 10),
              ),
            ),
          ),
          Container(
            height: 100,
            width: 100,
            color: Colors.blue,
            child: Text('Second Widget',
              style: TextStyle(color: Colors.white,fontSize: 10),),
          ),
        ],
      )
    ],
    ),
    ),
    ),
    );
  }
}