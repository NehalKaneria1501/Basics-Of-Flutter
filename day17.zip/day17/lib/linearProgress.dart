import 'dart:async';
import 'package:flutter/material.dart';

class Progressive extends StatefulWidget {
  const Progressive({super.key});

  @override
  State<Progressive> createState() => _ProgressiveState();
}

class _ProgressiveState extends State<Progressive> {
  bool _loading = false;
  double _progressValue = 0.0;

  @override
  void initState() {
    super.initState();
    _loading = false;
    _progressValue = 0.0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purpleAccent,
        title: Text("Progress Report"),
        actions: [Icon(Icons.score_outlined)],
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(8),
          child: _loading
              ? Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              LinearProgressIndicator(
                backgroundColor: Colors.cyanAccent,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
                value: _progressValue,
              ),
              Text("${(_progressValue * 100).round()}%"),
            ],
          )
              : Text(
            "Press Button for downloading",
            style: TextStyle(fontSize: 25),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _loading = !_loading;
            if (_loading) {
              _updateProgress();
            }
          });
        },
        tooltip: 'Download',
        child: Icon(Icons.cloud_download_outlined),
      ),
    );
  }

  void _updateProgress() {
    const oneSec = Duration(seconds: 1);
    Timer.periodic(oneSec, (Timer t) {
      setState(() {
        _progressValue += 0.1;
        if (_progressValue >= 1.0) {
          _progressValue = 1.0;
          _loading = false;
          t.cancel();
        }
      });
    });
  }
}
