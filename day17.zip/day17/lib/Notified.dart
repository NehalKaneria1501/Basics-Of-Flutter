import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Notified extends StatefulWidget {
  const Notified({super.key});

  @override
  State<Notified> createState() => _NotifiedState();
}

class _NotifiedState extends State<Notified> {
  void showToast(){
    Fluttertoast.showToast(
        msg: 'This is toast notified',
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.redAccent,
      textColor: Colors.yellowAccent,
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigoAccent,
        title: Text('Toast Notification Example'),
        actions: [Icon(Icons.notification_add_outlined)],
      ),
      body: Padding(
          padding: EdgeInsets.all(15),
          child: Center(
            child: ElevatedButton(
              child: Text('Click To Show'),
                onPressed: showToast,
                 ),
          ),
        ),
      );
  }
}
void main()=>runApp(ToastExample() as Widget);

ToastExample() {
}
