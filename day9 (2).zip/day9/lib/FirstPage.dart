import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class Firstpage extends StatefulWidget {
  const Firstpage({super.key});

  @override
  State<Firstpage> createState() => _FirstpageState();
}

class _FirstpageState extends State<Firstpage> {
  TextEditingController myController=TextEditingController();
  TextEditingController phone=TextEditingController();
  TextEditingController mail=TextEditingController();
  TextEditingController text=TextEditingController();
  TextEditingController registrationid=TextEditingController();
  TextEditingController pass=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Kids Diwali Registration",
        style: TextStyle(fontSize: 24,color: Colors.white),),
        actions: [Icon(Icons.home,color: Colors.white)],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height/11,
              width: MediaQuery.of(context).size.width,
              margin: EdgeInsets.all(10),
              padding: EdgeInsets.all(10),
              alignment:Alignment(0, 1),
              constraints: BoxConstraints.expand(height: 60),
              decoration: BoxDecoration(
                color: Colors.blueAccent,
                border: Border.all(color: Colors.black,width: 5),
                boxShadow:[BoxShadow(
                  color:Colors.yellowAccent,
                  offset:Offset (1.7, 1.0),
                ),
                ],
              ),
              child: RichText(
                  text: TextSpan(
                    children: [TextSpan(
                      text: 'Happy Diwali' ,
                      style: TextStyle(fontSize: 14,color: Colors.white)
                    ),
                      TextSpan(
                        text:'-Din Din Diwali',
                        style: TextStyle(fontSize: 14,color: Colors.yellowAccent),
                        recognizer: TapGestureRecognizer(),
                      ),
                      WidgetSpan(
                        child: Padding(
                            padding:EdgeInsets.symmetric(horizontal: 1.0),
                          child: Icon(Icons.login),
                        ),
                      ),
                    ],
                  ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: myController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'UserName',
                  hintText: "Enter Your Full Name",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: phone,
                maxLength: 10,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Phone',
                  hintText: "Enter Your Contact Details",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: mail,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'EmailId',
                  hintText: "Enter Your Email Address",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: text,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'City/Province',
                  hintText: "Enter your City Name with Province",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: registrationid,
                decoration:InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Id No.',
                  hintText: "Enter Your Registered Id No.",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: pass,
                maxLength: 8,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'PassWord',
                  hintText: "Enter Your PassWord",
                ),
              ),
            ),
            ElevatedButton(onPressed:(){
              alertdialog();
            },
                child:Text("SignUp")),
          ],
        ),
      ),
    );
  }
  Future alertdialog(){
    return showDialog(context: context, builder:(context){
      return AlertDialog(
        title: Text("Alert Messenger"),
        content: Text(registrationid.text),
        actions: [ElevatedButton(onPressed: (){
          Navigator.of(context).pop();
        }, child: Text("Ok")),
        ],
      );
    });
  }
}