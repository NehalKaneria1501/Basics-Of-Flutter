import 'package:flutter/material.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int count=0;
  int table=0;
  int passengers=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Diwali FireWorks",
        style: TextStyle(fontSize: 24,color: Colors.white),),
        actions: [Icon(Icons.account_circle,color: Colors.white,),],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
                decoration: BoxDecoration(color: Colors.lightGreenAccent,
                ),
              child: Text("Baps Toronto Diwali Celebration",
              style: TextStyle(fontSize: 24,color:Colors.black ),),
            ),
            ListTile(
              title: Text("Ottawa Parliament"),
              subtitle:Text("Diwali Celebration By Hindu Community"),
              leading: Icon(Icons.restaurant),
            ),
            Divider(
              height: 1.0,
            ),
            ListTile(
              title: Text("WelCome Registration Center"),
            ),
            ListTile(
              title: Text("Hindu Community New Year Celebration Assembly"),
            ),
            ListTile(
              title: Text("Annkut Exhibition Hall"),
            ),
            ListTile(
              title: Text("Meal Mess Shayona Dinning Hall"),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 500,
              width: 500,
              margin: EdgeInsets.all(10),
              padding: EdgeInsets.all(10),
              child: Center(child: Text("Traditional Haveli",style: TextStyle(fontSize: 20,color:Colors.redAccent )),
              ),
              constraints: BoxConstraints.expand(height: 170),
              decoration: BoxDecoration(
                color: Colors.lightGreenAccent,border: Border.all(color:Colors.cyanAccent),
                borderRadius: BorderRadius.circular(7),
                boxShadow: [new BoxShadow(color: Colors.blue,offset: Offset(7.0, 7.0))]
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  margin: EdgeInsets.all(10),
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color:Colors.blueAccent,
                  ),
                  child: Text("Jay Diwali",style: TextStyle(fontSize: 17,color: Colors.white)),
                ),
              ],
            ),
            IconButton(
              icon: Icon(Icons.car_rental_outlined),
              iconSize:50,
              color:Colors.blueAccent,
              tooltip:'passengers',
              onPressed: (){
                setState(() {
                  passengers+=5;
                });
                Text('Passengers:$passengers');
              },
            ),
            InkWell(
              splashColor:Colors.white70,
              highlightColor: Colors.black12,
              child: Icon(Icons.dining_outlined),
              onTap:(){
                setState(() {
                  table+=1;
                });
              },
            ),
            Text(
              table.toString(),
              style: TextStyle(fontSize: 50),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(onPressed: (){
        setState(() {
          count++;
        });
      },
      child:Icon(Icons.add),
        backgroundColor: Colors.lightBlueAccent,
        foregroundColor: Colors.white,
      ),
      bottomNavigationBar: BottomNavigationBar(
          items:[
            BottomNavigationBarItem(icon: Icon(Icons.home),label: "Home"),
            BottomNavigationBarItem(icon: Icon(Icons.search_rounded),label: "Search_rounded"),
            BottomNavigationBarItem(icon: Icon(Icons.settings),label:"Settings"),
          ]),
    );
  }
}