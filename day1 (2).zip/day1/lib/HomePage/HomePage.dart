import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("HomeScren",style: TextStyle(fontSize: 20,color:Colors.white, ),),
        leading: Icon(Icons.arrow_back,color:Colors.white ,),
        actions: [
          Icon(Icons.search_rounded,color:Colors.white),
        ],
      ),
    );
  }
}
