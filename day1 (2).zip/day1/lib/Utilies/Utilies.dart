import 'package:flutter/material.dart';

class Utilies extends StatefulWidget {
  const Utilies({super.key});

  @override
  State<Utilies> createState() => _UtiliesState();
}

class _UtiliesState extends State<Utilies> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      backgroundColor: Colors.blue,
      title:Text("Utilies",style:TextStyle(fontSize:21,color:Colors.white,),),
      leading:Icon(Icons.arrow_back,color:Colors.black,),
      actions: [Icon(Icons.search_rounded,color:Colors.white,),]
      )
    );
  }
}
