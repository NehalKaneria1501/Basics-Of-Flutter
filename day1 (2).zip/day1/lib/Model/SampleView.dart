
import 'package:flutter/material.dart';

class Sampleview extends StatefulWidget {
  const Sampleview({super.key});

  @override
  State<Sampleview> createState() => _SampleviewState();
}

class _SampleviewState extends State<Sampleview> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
