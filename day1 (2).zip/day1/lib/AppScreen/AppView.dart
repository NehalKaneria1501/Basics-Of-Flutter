
import 'package:flutter/material.dart';

class AppView extends StatefulWidget {
  const AppView({super.key});

  @override
  State<AppView> createState() => _AppViewState();
}

class _AppViewState extends State<AppView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
      backgroundColor: Colors.black,
        title:Text("AppView",style:TextStyle(fontSize:20,color:Colors.blue,),),
            leading:Icon(Icons.arrow_back,color:Colors.white,),
        actions:[Icon(Icons.search_rounded,color:Colors.white),]
      )
    );
  }
}
