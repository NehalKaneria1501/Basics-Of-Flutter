import 'package:day32/multimedia.dart';
import 'package:flutter/material.dart';

class Rnw extends StatefulWidget {
  const Rnw({super.key});

  @override
  State<Rnw> createState() => _RnwState();
}

class _RnwState extends State<Rnw> {
  final _formKey = GlobalKey<FormState>();
  int _GetCode=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.tealAccent[100],
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 90,
            ),
            Container(
              height: MediaQuery.of(context).size.height / 1.3,
              width: MediaQuery.of(context).size.width / 1.1,
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(2.0, 3.0),
                    spreadRadius: 5.0,
                    blurRadius: 5.0,
                  ),
                ],
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 75,
                  ),
                  Icon(Icons.battery_4_bar_rounded,
                  color: Colors.white,
                    shadows: [
                      Shadow(color: Colors.black),
                    ],
                  ),
                  SizedBox(
                    height: 100,
                  ),
                  Center(
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Phone Number Login:",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          TextFormField(
                            decoration: InputDecoration(
                              hintText: "Enter your phone number",
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(28),
                              ),
                              prefixIcon: Icon(Icons.phone),
                              fillColor: Colors.white,
                              filled: true,
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          TextFormField(
                            decoration: InputDecoration(
                              hintText: "Password",
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(28),
                              ),
                              prefixIcon: Icon(Icons.security),
                              suffix: ElevatedButton(
                                style: ButtonStyle(
                                  backgroundColor:WidgetStatePropertyAll<Color>(Colors.black)
                                ),
                                onPressed: () {
                                  alertdialog(context);
                                },
                                child: Text(
                                  "Get Code",
                                  style: TextStyle(color: Colors.green),

                                ),
                              ),
                              fillColor: Colors.white,
                              filled: true,
                            ),
                          ),
                          SizedBox(
                            height: 50,
                          ),
                          InkWell(
                            onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Multimedia()));

                            },
                            child: Container(
                              height: 35,
                              width: MediaQuery.of(context).size.width / 0.8,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(28),
                                color: Colors.black,
                              ),
                              child: Center(
                                child: Text(
                                  "Log In",
                                  style: TextStyle(
                                      fontSize: 23, color: Colors.green),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
Future alertdialog(BuildContext context) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text("Get Code"),
        content: Text('20250101'),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text(
              "20250101",
              style: TextStyle(color: Colors.green),
            ),
          ),
        ],
      );
    },
  );
}
