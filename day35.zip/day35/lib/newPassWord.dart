import 'package:day35/signUp.dart';
import 'package:flutter/material.dart';

class Newpassword extends StatefulWidget {
  const Newpassword({super.key});

  @override
  State<Newpassword> createState() => _NewpasswordState();
}

class _NewpasswordState extends State<Newpassword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text('New Password',
          textAlign: TextAlign.center,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 150,
              padding: EdgeInsets.all(8),
              margin: EdgeInsets.all(8),
            ),
            Text(
              'Enter New Password',
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                  hintText: 'At least 6 digits'
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              'Confirm Password',
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                  hintText: '......'
                ),
              ),
            ),
            SizedBox(
              height: 60,
            ),
            TextButton(
              style: ButtonStyle(
                  backgroundColor:WidgetStatePropertyAll<Color>(Colors.deepOrangeAccent),
              ),
                onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>Signup()));
            },
                child: Container(
                  width: 350,
                  child: Text('Send',
                  style: TextStyle(
                      color: Colors.white
                  ),
                    textAlign: TextAlign.center,
                  ),
                ),
            ),
          ],
        ),
      ),
    );
  }
}