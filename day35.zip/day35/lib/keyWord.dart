import 'package:day35/signUp.dart';
import 'package:day35/veriFication.dart';
import 'package:flutter/material.dart';

class Keyword extends StatefulWidget {
  const Keyword({super.key});

  @override
  State<Keyword> createState() => _KeywordState();
}

class _KeywordState extends State<Keyword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar: AppBar(
      backgroundColor: Colors.white,
      title: Text('Forgot Password',
        style: TextStyle(
          color: Colors.black,
        ),
      ),
    ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 100,
            ),
            Text('Enter Email Address',
            textAlign: TextAlign.center,),
            SizedBox(
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.all(18.0),
              child: TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28)
                  ),
                  hintText: 'example@gmail.com',
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Text('Back to sign in',
            textAlign: TextAlign.center,),
            SizedBox(
              height: 30,
            ),
            Container(
              width: 300,
              child: TextButton(
                style: ButtonStyle(
                  backgroundColor: WidgetStatePropertyAll<Color>(Colors.deepOrange),
                ),
                  onPressed: (){
                Navigator.push(context, MaterialPageRoute(
                    builder:(context)=>Verification()
                ),
                );
              },
                  child: Text('Send',
                  style: TextStyle(
                      color: Colors.white),
                  textAlign: TextAlign.center),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Text('or',
            style: TextStyle(color: Colors.deepOrange),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                    Icons.facebook_outlined
                ),
                SizedBox(
                  width: 5,
                ),
                Icon(
                  Icons.abc_outlined
                ),
                SizedBox(
                  width: 5,
                ),
                Icon(
                  Icons.apple_outlined
                ),
        ],
      ),
            SizedBox(
              height: 50,
            ),
            Text('Do you have an account?',
              textAlign: TextAlign.center,
            ),
                SizedBox(
                  height: 10,
                ),
                  TextButton(
                      onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Signup()));
                  },
                      child: Container(
                        height: 50,
                        width: 300,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black,
                            offset: Offset.fromDirection(1.0, 1.0),
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text('Sign up',
                          textAlign: TextAlign.center),
                        ),
                      ),
                  ),
              ],
            )
      ),
        );
  }
}