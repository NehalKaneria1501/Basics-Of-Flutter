import 'package:day35/newPassWord.dart';
import 'package:day35/signUp.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
class Verification extends StatefulWidget {
  const Verification({super.key});
  @override
  State<Verification> createState() => _VerificationState();
}
class _VerificationState extends State<Verification> {
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Verification',
          ),
        ),
        body: Column(
          children: [
            SizedBox(
              height: 100,
            ),
            Container(
              child: Center(
                child: Text(
                  "Enter verification Code",
                  style: TextStyle(
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              child: OtpTextField(
                numberOfFields: 4,
                borderRadius: BorderRadius.circular(30),
                borderColor: Color(0xFF512DA8),
                showFieldAsBox: true,
                onCodeChanged: (String code) {},
                onSubmit: (String verificationCode) {
                  showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: Text(
                              "Verification Code"
                          ),
                          content: Text(
                              'Code entered is $verificationCode'
                          ),
                        );
                      }
                  );
                }, // end onSubmit
              ),
            ),
            RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'If you didnot recive a code' ,
                      style: TextStyle(
                        color: Colors.black
                      ),
                    ),
                    TextSpan(
                      text: ' Resend',
                      style: TextStyle(
                        color: Colors.deepOrangeAccent
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap=(){}
                    ),
                 ]
                ),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.all(28.0),
              child: TextButton(
                style: ButtonStyle(
                  backgroundColor:
                  WidgetStatePropertyAll<Color>
                    (Colors.deepOrangeAccent)
                ),
                  onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder:
                      (context)=>Newpassword()));
              },
                  child: Center(
                    child: Text(
                      'Send',
                    style: TextStyle(
                        color: Colors.white
                    ),
                    ),
                  ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              'or',
              style: TextStyle(
                  color: Colors.deepOrangeAccent
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                    Icons.facebook_outlined
                ),
                SizedBox(
                  width: 10,
                ),
                Icon(
                  Icons.abc_outlined
                ),
                SizedBox(
                  width: 10,
                ),
                Icon(
                  Icons.apple_outlined
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Text(
                'Do you have an account?'
            ),
            TextButton(
                onPressed: (){
              Navigator.push(context,MaterialPageRoute(builder: (context)=>Signup()));
            },
              child: Container(
                height: 30,
                width: 300,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset.fromDirection(1.5, 1.5),
                    ),
                  ],
                ),
                child:Center(
                  child: Text(
                      'Sign up',
                  textAlign: TextAlign.center
                  ),
                ),
            )
            ),
      ],
        ),
    );
  }
}