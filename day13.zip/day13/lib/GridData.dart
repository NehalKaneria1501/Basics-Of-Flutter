import 'package:flutter/material.dart';

class Griddata extends StatefulWidget {
  const Griddata({super.key});

  @override
  State<Griddata> createState() => _GriddataState();
}

class _GriddataState extends State<Griddata> {
  final String appTitle = "Flutter Grid List Demo";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("GridList", style: TextStyle(fontSize: 24, color: Colors.black)),
        actions: [Icon(Icons.account_box_outlined)],
      ),
      body: GridView.count(
        crossAxisCount: 3,
        children: List.generate(
          choices.length,
              (index) {
            return Center(
              child: SelectedCard(choice: choices[index]),
            );
          },
        ),
      ),
    );
  }
}

// Define the Choice class outside the Griddata widget
class Choice {
  const Choice({this.title, this.icon});

  final String? title; // Nullable String
  final IconData? icon; // Nullable IconData
}

// Sample list of choices
const List<Choice> choices = const <Choice>[
  const Choice(title: 'Home', icon: Icons.home),
  const Choice(title: 'Contact', icon: Icons.contacts),
  const Choice(title: 'Map', icon: Icons.map_outlined),
  const Choice(title: 'Phone', icon: Icons.phone),
  const Choice(title: 'Camera', icon: Icons.camera_enhance_outlined),
  const Choice(title: 'Setting', icon: Icons.settings),
  const Choice(title: 'Album', icon: Icons.photo_album_outlined),
  const Choice(title: 'WiFi', icon: Icons.wifi),
  const Choice(title: 'GPS', icon: Icons.gps_fixed_outlined),
];

// Define the SelectedCard widget outside the Griddata widget
class SelectedCard extends StatelessWidget {
  const SelectedCard({Key? key, this.choice}) : super(key: key);
  final Choice? choice;

  @override
  Widget build(BuildContext context) {
   // final TextStyle textStyle = Theme.of(context).textTheme.bodyMedium;
    return Card(
      color: Colors.lightGreenAccent,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(
              child: Icon(
                choice!.icon,
                size: 50,
                color:Colors.blueGrey,
              ),
            ),
            Text(choice!.title.toString()),
          ],
        ),
      ),
    );
  }
}