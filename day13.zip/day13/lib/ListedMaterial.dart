import 'package:flutter/material.dart';

class Listedmaterial extends StatefulWidget {
  const Listedmaterial({super.key});

  @override
  State<Listedmaterial> createState() => _ListedmaterialState();
}

class _ListedmaterialState extends State<Listedmaterial> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Players List",
        style: TextStyle(fontSize: 24,color: Colors.black),),
        actions: [Icon(Icons.account_box_outlined)],
      ),
      body: ListView(
        children: <Widget>[
          ListTile(
            leading: Icon(Icons.map_outlined),
            title: Text("Map"),
          ),
          ListTile(
            leading: Icon(Icons.photo_album_outlined),
            title: Text("Album"),
          ),
          ListTile(
            leading: Icon(Icons.phone_android_outlined),
            title: Text("Phone"),
          ),
          ListTile(
            leading: Icon(Icons.contacts_outlined),
            title: Text("Contacts"),
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text("Settings"),
          ),
        ],
      ),
    );
  }
}