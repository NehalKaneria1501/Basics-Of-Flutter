import 'package:flutter/material.dart';

class Horizontallist extends StatefulWidget {
  const Horizontallist({super.key});

  @override
  State<Horizontallist> createState() => _HorizontallistState();
}

class _HorizontallistState extends State<Horizontallist> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("HrList",
        style: TextStyle(fontSize: 24,color: Colors.black)),
        actions: [Icon(Icons.account_box_outlined)],
      ),
      body: Container(
        margin: EdgeInsets.symmetric(vertical: 25),
        height: 150,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children:<Widget>[
            Container(
              width: 150,
              child: new Stack(
                children:<Widget>[
                  ListTile(
                    leading: Icon(Icons.home),
                    title: Text("Home"),
                  ),
                  ],
              ),
            ),
                  Container(
                    width: 150,
                    child: new Stack(
                      children: <Widget>[
                        ListTile(
                          leading: Icon(Icons.camera_alt_outlined),
                        ),
                        ],
                    ),
                  ),
                        Container(
                          width: 150,
                          child: new Stack(
                            children: <Widget>[
                              ListTile(
                                leading: Icon(Icons.phone),
                              ),
                              ],
                          ),
                        ),
                              Container(
                                width: 150,
                                child: new Stack(
                                  children: <Widget>[
                                    ListTile(
                                      leading: Icon(Icons.map_outlined),
                                    ),
                                    ],
                                ),
                              ),
                                    Container(
                                      width:150,
                                      child: new Stack(
                                        children: <Widget>[
                                          ListTile(
                                            leading: Icon(Icons.settings),
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
    );
  }
}