import 'package:flutter/material.dart';

class Longlist extends StatefulWidget {
  const Longlist({super.key});

  @override
  State<Longlist> createState() => _LonglistState();
}

class _LonglistState extends State<Longlist> {
  // Define the products list
  final List<String> products = [
    'Product 1',
    'Product 2',
    'Product 3',
    'Product 4',
    'Product 5',
    // Add more products as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text(
          "Auction List",
          style: TextStyle(fontSize: 24, color: Colors.black), // Corrected fontSize
        ),
        actions: [Icon(Icons.account_box_outlined, color: Colors.black)],
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('${products[index]}'),
          );
        },
      ),
    );
  }
}
