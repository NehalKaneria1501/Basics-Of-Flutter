import 'package:flutter/material.dart';
import 'package:flutter_swipe/flutter_swipe.dart';

class Slide extends StatefulWidget {
  const Slide({super.key});

  @override
  State<Slide> createState() => _SlideState();
}

class _SlideState extends State<Slide> {
  int _value = 6;
  RangeValues _currentRangeValues = const RangeValues(20, 60);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("Flutter Slider Example"),
        actions: [Icon(Icons.landslide_outlined)],
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(
                Icons.volume_up_outlined,
                size: 40,
              ),
              Expanded(
                child: Slider(
                  value: _value.toDouble(),
                  min: 1.0,
                  max: 20.0,
                  divisions: 10,
                  activeColor: Colors.green,
                  inactiveColor: Colors.orange,
                  label: 'Volume: ${_value.toString()}',
                  onChanged: (double newValue) {
                    setState(() {
                      _value = newValue.round();
                    });
                  },
                  semanticFormatterCallback: (double newValue) {
                    return 'Volume at ${newValue.round()}';
                  },
                ),
              ),
              Expanded(
                child: RangeSlider(
                  values: _currentRangeValues,
                  min: 0,
                  max: 100,
                  divisions: 10,
                  labels: RangeLabels(
                    _currentRangeValues.start.round().toString(),
                    _currentRangeValues.end.round().toString(),
                  ),
                  onChanged: (RangeValues values) {
                    setState(() {
                      _currentRangeValues = values;
                    });
                  },
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                margin: EdgeInsets.all(10),
                alignment: Alignment.center,
                constraints: BoxConstraints.expand(
                  height: 225,
                ),
                child: imageSlider(context),
              ),
        ],
          ),
        ),
          ),
        );
  }
}
Swiper imageSlider(context){
  return new Swiper(
    autoplay: true,
    itemBuilder: (BuildContext context,int index){
      return new Image.network("https://lh3.googleserconnect.com/wlcl3tehFmOUq-JL3hlVbZVFrLHePRtIDWV5IZwBVDr7kEAgLTChyXUclMVQDRHDEcDEcDhY=w640-h400-e365-rj-scOxOOffffff",
      fit: BoxFit.fitHeight,
      );
    },
    itemCount: 10,
    viewportFraction: 0.7,
    scale: 0.8,
  );
}