package com.example.day2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
