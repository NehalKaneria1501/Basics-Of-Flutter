import 'package:flutter/material.dart';
class Utilies extends StatefulWidget {
  const Utilies({super.key});
  @override
  State<Utilies> createState() => _UtiliesState();
}
class _UtiliesState extends State<Utilies> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     appBar: AppBar(
       backgroundColor: Colors.red,
       title: Text("Utilies",
       style: TextStyle(fontSize:25,color:Colors.white,),),
      actions:[Icon(Icons.search_rounded,color:Colors.white),]
     ),
      drawer:Drawer(
        child:ListView(
          children: [
            DrawerHeader(
              decoration:BoxDecoration(
                color:Colors.lightBlue,
        ),
                child:Text(
                  "This is my utilies",
          style:TextStyle(color:Colors.white),
              )),
    ListTile(
    title:Text('1'),
    ),
    ListTile(
      title:new Text("My all utilies file"),
      subtitle:Text("my directory file"),
      leading: new Icon(Icons.message),
    ),
        Divider(
          height:0.7,
        ),
        ListTile(
          title:Text("protocol"),
        ),
        ],
        ),
    ),
      body:Center(
        child:Text("It is my directory protocol"),
      )
    );
  }
}