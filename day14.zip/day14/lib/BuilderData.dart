import 'package:flutter/material.dart';

class Builderdata extends StatefulWidget {
  const Builderdata({super.key});

  @override
  State<Builderdata> createState() => _BuilderdataState();
}

class _BuilderdataState extends State<Builderdata> {
  // Example list of images. Replace this with your actual image URLs.
  List<String> images = [
    "https://via.placeholder.com/150",
    "https://via.placeholder.com/150",
    "https://via.placeholder.com/150",
    "https://via.placeholder.com/150",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightGreenAccent,
        title: Text(
          "Construction Report",
          style: TextStyle(fontSize: 24, color: Colors.black),
        ),
        actions: [
          Icon(
            Icons.account_box_outlined,
            color: Colors.black,
          )
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(12),
        color: Colors.pinkAccent,
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 4,
            mainAxisSpacing: 4,
          ),
          itemCount:images.length, // Set the number of items in the grid
          itemBuilder: (BuildContext context, int index) {
            return Image.network(images[index]);
          },
        ),
      ),
    );
  }
}