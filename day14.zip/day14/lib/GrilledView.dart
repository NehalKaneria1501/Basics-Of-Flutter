import 'package:flutter/material.dart';

class Grilledview extends StatefulWidget {
  const Grilledview({super.key});

  @override
  State<Grilledview> createState() => _GrilledviewState();
}

class _GrilledviewState extends State<Grilledview> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightGreenAccent,
        title: Text("Extended",style: TextStyle(fontSize: 24,color: Colors.black)),
        actions: [Icon(Icons.account_box_outlined)],
      ),
      body: Center(
        child: GridView.extent(
            primary: false,
        padding: const EdgeInsets.all(15),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        maxCrossAxisExtent: 200,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('First',style: TextStyle(fontSize: 24)),
            color: Colors.yellowAccent,
      ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Second',style: TextStyle(fontSize: 24)),
          color: Colors.blueAccent),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Third', style: TextStyle(fontSize: 24)),
            color: Colors.blue,
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Fourth',style: TextStyle(fontSize: 24)),
            color: Colors.yellow,
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Fifth',style: TextStyle(fontSize: 24)),
            color: Colors.cyan,
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Sixth',style: TextStyle(fontSize: 24)),
            color:Colors.cyanAccent,
          ),
        ],),
      ),
    );
  }
}