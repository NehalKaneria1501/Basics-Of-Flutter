import 'package:flutter/material.dart';

class Diamondtower extends StatefulWidget {
  const Diamondtower({super.key});

  @override
  State<Diamondtower> createState() => _DiamondtowerState();
}

class _DiamondtowerState extends State<Diamondtower> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            actions: <Widget>[
              Icon(Icons.camera_alt_outlined),
            ],
            title: Text("Silver Grid Example"),
            leading: Icon(Icons.menu),
            backgroundColor: Colors.green,
            expandedHeight: 100,
            floating: true,
            pinned: true,
          ),
          SliverGrid(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
            ),
            delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                return Container(
                  color: _randomPaint(index),
                  height: 100,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  Color _randomPaint(int index) {
    if (index % 3 == 1) {
      return Colors.orangeAccent;
    } else if (index % 3 == 1) {
      return Colors.blue;
    }
    return Colors.redAccent;
  }
}