import 'package:flutter/material.dart';

class Silverheight extends StatefulWidget {
  const Silverheight({super.key});

  @override
  State<Silverheight> createState() => _SilverheightState();
}

class _SilverheightState extends State<Silverheight> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget>[
       SliverAppBar(
      pinned: true,
        expandedHeight: 250.0,
        flexibleSpace: FlexibleSpaceBar(
          title: Text('Silver App Bar Example'),
        ),
      ),
      ],
      ),
    );
  }
}
