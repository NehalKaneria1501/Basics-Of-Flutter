import 'package:flutter/material.dart';

class Platiniumtower extends StatefulWidget {
  const Platiniumtower({super.key});

  @override
  State<Platiniumtower> createState() => _PlatiniumtowerState();
}

class _PlatiniumtowerState extends State<Platiniumtower> {
  @override
  Widget build(BuildContext context) {
    var actions;
    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget> [
       SliverFixedExtentList(
        itemExtent: 50.0,
        delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
            return Container(
              alignment: Alignment.center,
              color: Colors.lightBlue[100 * (index % 9)],
              child: Text('list item $index'),
            );
          },
    ),
    ),
          SliverToBoxAdapter(
                 child: Column(
                  children: [
                    Container(
                      height: 100,
                      color: Colors.cyan,
                    ),
                  ],
                ),
    ),
          ],
    ),
      );
  }
}