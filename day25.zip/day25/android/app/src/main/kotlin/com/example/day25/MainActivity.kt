package com.example.day25

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
