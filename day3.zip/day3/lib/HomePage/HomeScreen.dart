import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text(
          "Welcome",
          style: TextStyle(fontSize: 26.13, color: Colors.white),
        ),
        actions: [
          Icon(Icons.search_rounded, color: Colors.white),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                "This is my app",
                style: TextStyle(color: Colors.orange),
              ),
            ),
            ListTile(
              title: Text('1'),
            ),
            ListTile(
              title: Text("This is my app stack"),
              subtitle: Text("I have stored my data"),
              leading: Icon(Icons.home),
            ),
            Divider(
              height: 0.7,
            ),
            ListTile(
              title: Text("Have a nice day"),
            ),
          ],
        ),
      ),
      body: Center(
        child: Text("Thank you, visit again"),
      ),
    );
  }
}