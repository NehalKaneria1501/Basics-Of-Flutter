import 'package:flutter/material.dart';

class Ea25 extends StatefulWidget {
  const Ea25({super.key});

  @override
  State<Ea25> createState() => _Ea25State();
}

class _Ea25State extends State<Ea25> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigoAccent,
        title: Text("Hakuna Matata",),
        actions: [Icon(Icons.travel_explore_outlined)],
      ),
    );
  }
}
