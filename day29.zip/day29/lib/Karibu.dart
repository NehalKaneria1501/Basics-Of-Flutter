import 'package:day29/eA25.dart';
import 'package:flutter/material.dart';

class Karibu extends StatefulWidget {
  const Karibu({super.key});

  @override
  State<Karibu> createState() => _KaribuState();
}

class _KaribuState extends State<Karibu> {
  final _formKey=GlobalKey<FormState>();
  void login=1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
            padding: EdgeInsets.all(0),
          child: Container(
            height:MediaQuery.of(context).size.height/1,
            width: MediaQuery.of(context).size.width/1,
            margin: EdgeInsets.all(0),
            padding: EdgeInsets.all(28),
            decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter,
                  colors:[Colors.indigoAccent,Colors.white],
              ),
            ),
                child: Column(
                  key: _formKey,
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height/3,
                    ),
                    Text("Login",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height/7,
                      width: MediaQuery.of(context).size.width/7,
                    ),
                    TextFormField(style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        border:OutlineInputBorder(),
                        hintText: "Email or Phone number",
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height/95,
                    ),
                    TextFormField(style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        border:OutlineInputBorder(),
                        hintText: "Password",
                      ),
                    ),
                 SizedBox(
                   height: MediaQuery.of(context).size.height/30,
                 ),
                 InkWell(
                   onTap: (){
                     Navigator.push(context, MaterialPageRoute(builder: (context)=>Ea25()));
                   },
                   child: Container(
                     height: 40,
                     width: 400,
                     decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(5),
                       gradient: LinearGradient(colors: [Colors.indigoAccent,Colors.white]),
                     ),
                     child: Text("Login",style: TextStyle(color: Colors.white,fontSize: 21),textAlign: TextAlign.center,),
                   ),
                 ),
                    SizedBox(
                      height:MediaQuery.of(context).size.height/9,
                    ),
                    RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(text: "Forgot Password?",
                            style: TextStyle(color: Colors.indigoAccent))
                          ]
                        )),
                   ],
                ),
                ),
                ),
      ),
      );
  }
}
