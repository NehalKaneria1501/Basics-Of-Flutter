package com.example.day36

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
