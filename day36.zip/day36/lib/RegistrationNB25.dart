import 'package:day36/Anz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';

class Registrationnb25 extends StatefulWidget {
  const Registrationnb25({super.key});

  @override
  State<Registrationnb25> createState() => _Registrationnb25State();
}

class _Registrationnb25State extends State<Registrationnb25> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
        child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
    Padding(
    padding: const EdgeInsets.all(8.0),
    child: Container(
    width: MediaQuery.of(context).size.width/0.1,
      child:Image.asset(
        'assests/Images/Screenshot 2025-01-06 171244.jpg',
        scale: 0.1,
      ),
      height: MediaQuery.of(context).size.height/2.20,
    ),
    ),
          SizedBox(
            height: 50,
          ),
          RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: 'Registration\n',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 25,
                  ),
                ),
                TextSpan(
                  text: 'Enter the Code sent to\n',
                  style: TextStyle(
                    color: Colors.black,
                    height: 1.5,
                  ),
                ),
                TextSpan(
                  text: '   +123 456 789 0\n',
                  style: TextStyle(
                    color: Colors.indigoAccent,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            child: OtpTextField(
            numberOfFields: 4,
            borderRadius: BorderRadius.circular(30),
            borderColor: Color(0xFF512DA8),
            showFieldAsBox: true,
            onCodeChanged: (String code) {},
            onSubmit: (String verificationCode) {
              showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text(
                          "Verification Code"
                      ),
                      content: Text(
                          'Code entered is $verificationCode'
                      ),
                    );
                  }
              );
            }, // end onSubmit
          ),
          ),
          SizedBox(
            height: 20,
          ),
          RichText(
            text: TextSpan(
              text: 'I donot Recieve the Code!\n',
              style: TextStyle(
                  color: Colors.black
              ),
              children: [
                TextSpan(
                  text: 'Resend Code',
                  style: TextStyle(
                    color: Colors.indigoAccent,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          TextButton(
            onPressed: (){
              Navigator.push(context,
                  MaterialPageRoute(
                      builder: (context)=>Anz()
                  ),
              );
            },
            child: Container(
              height: 40,
              width: 350,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ]
                ),
              ),
              child: Center(
                child: Text(
                  "Verify",
                  style: TextStyle(
                      color:Colors.white
                  ),
                ),
              ),
            ),
          ),
    ],
        ),
        ),
        );
  }
}