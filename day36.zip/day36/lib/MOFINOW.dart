import 'dart:convert';
import 'package:day36/LoginModel.dart';
import 'package:flutter/material.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:gradient_icon/gradient_icon.dart';
import 'Welcome.dart';
import 'package:http/http.dart' as http;

class Mofinow extends StatefulWidget {
  const Mofinow({super.key});

  @override
  State<Mofinow> createState() => _MofinowState();
}

class _MofinowState extends State<Mofinow> {
  TextEditingController name=TextEditingController();
  TextEditingController mail=TextEditingController();
  TextEditingController password=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: MediaQuery.of(context).size.width/0.1,
                child: Image.asset(
                  "assests/Images/Screenshot 2025-01-05 140927.jpg",
                scale: 0.1,),
                height: MediaQuery.of(context).size.height/3,
              ),
            ),
            SizedBox(
              height: 100,
            ),
            Center(
              child: RichText(
                  text: TextSpan(
                    text: 'Welcome!',
                    style: TextStyle(
                        color: Colors.black,
                      fontSize: 25
                    )
                  ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(
              height:25,
            ),
            TextButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Welcome()));
              },
              child: Container(
                height: 40,
                width: 350,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: LinearGradient(
                      colors: [
                    Colors.indigo,
                    Colors.indigoAccent,
                        Colors.purpleAccent
                  ]
                  ),
                ),
                child: Center(
                  child: Text(
                    "Create Account",
                    style: TextStyle(
                        color:Colors.white
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            TextButton(
                onPressed: (){
                  fetchAlbum();
                  print("Login=========>>>>");
              Navigator.push(context,
                  MaterialPageRoute(
                      builder: (context)=>Welcome()
                  )
              );
            },
              child: Container(
                height: 40,
                width: 500,
                decoration: BoxDecoration(
                  border: const GradientBoxBorder(
                    width: 3,
                    gradient: LinearGradient(colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                    ),
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Center(
                  child: ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [
                        Colors.indigo,
                        Colors.indigoAccent,
                        Colors.purpleAccent
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: Text(
                      'Login',
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GradientIcon(
                  icon: Icons.message_outlined,
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                  ),
                ),
                SizedBox(
                    width: 10
                ),
                GradientIcon(
                  icon: Icons.work_outline_rounded,
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                  ),
                ),
                SizedBox(
                    width: 10
                ),
                GradientIcon(
                  icon: Icons.facebook_outlined,
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                  ),
                ),
                GradientIcon(
                    icon:Icons.g_mobiledata_rounded,
                    gradient: LinearGradient(
                      colors: [
                        Colors.indigo,
                        Colors.indigoAccent,
                        Colors.purpleAccent
                      ],
                    ),
                ),
            ],
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              "Sign in with another account",
              textAlign: TextAlign.center,
            )
        ],
        ),
                ),
      );
  }
  Future<LoginModel> fetchAlbum() async {
    final response = await http.get(
        Uri.parse('https://reqres.in/api/login')
    );
    if (response.statusCode == 200) {
      print("Login Success");
      LoginModel loginModel = LoginModel.fromJson(jsonDecode(response.body));
      return loginModel;
    }
    else {
      throw Exception('Failed to load album');
    }
  }
}