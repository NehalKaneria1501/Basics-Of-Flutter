import 'package:day36/RegistrationNB25.dart';
import 'package:flutter/material.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:gradient_icon/gradient_icon.dart';

class Welcome extends StatefulWidget {
  const Welcome({super.key});

  @override
  State<Welcome> createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  bool _RememberMe = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: MediaQuery.of(context).size.width / 0.1,
                child: Image.asset(
                  "assests/Images/Screenshot 2025-01-05 140927.jpg",
                  scale: 0.1,
                ),
                height: MediaQuery.of(context).size.height / 3,
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Center(
              child: RichText(
                text: TextSpan(
                    text: 'Welcome back!',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 25
                    )
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                style: TextStyle(
                  color: Colors.black12,
                ),
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Username",
                  fillColor: Colors.grey[100],
                  filled: true,
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                style: TextStyle(color: Colors.black12),
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.remove_red_eye_outlined),
                  hintText: "Password",
                  fillColor: Colors.grey[100],
                  filled: true,
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            ListTile(
              title: Text('Remember me'),
              leading: Radio<bool>(
                value: false,
                groupValue: _RememberMe,
                onChanged: (bool? value) {
                  setState(() {
                    _RememberMe = value ?? false;
                  });
                },
              ),
            ),
            TextButton(
              onPressed:(){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Registrationnb25()));
              },
                child: Text(
                    'Forgot password?'
                ),
            ),
            SizedBox(
              height: 5,
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Welcome()));
              },
              child: Container(
                height: 40,
                width: 500,
                decoration: BoxDecoration(
                  border: const GradientBoxBorder(
                    width: 3,
                    gradient: LinearGradient(colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ]),
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Center(
                  child: ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [
                        Colors.indigo,
                        Colors.indigoAccent,
                        Colors.purpleAccent
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: Text(
                      'Login',
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            ShaderMask(
              shaderCallback: (bounds) {
                return LinearGradient(
                  colors: [
                    Colors.indigo,
                    Colors.indigoAccent,
                    Colors.purpleAccent,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds);
              },
              child: RichText(
                text: TextSpan(
                  text: 'New User? ',
                  style: TextStyle(
                      color: Colors.white
                  ),
                  children: [
                    TextSpan(
                      text: 'Sign Up',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 1,
                  height: 20,
                  color: Colors.black,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text(
                    'OR',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
                Container(
                  width: 1,
                  height: 20,
                  color: Colors.black,
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GradientIcon(
                  icon: Icons.message_outlined,
                  size: 24.0,
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                  ),
                ),
                SizedBox(
                    width: 10
                ),
                GradientIcon(
                  icon: Icons.work_outline_rounded,
                  size: 24.0,
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                  ),
                ),
                SizedBox(
                    width: 10
                ),
                GradientIcon(
                  icon: Icons.facebook_outlined,
                  size: 24.0,
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                  ),
                ),
                GradientIcon(
                  icon: Icons.g_mobiledata_rounded,
                  size: 24.0,
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo,
                      Colors.indigoAccent,
                      Colors.purpleAccent
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 15,
            ),
            Text(
                'Sign in with another account',
            textAlign: TextAlign.center
            ),
          ],
        ),
      ),
    );
  }
}