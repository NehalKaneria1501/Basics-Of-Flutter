import 'package:flutter/material.dart';

class Myappview extends StatefulWidget {
  const Myappview({super.key});

  @override
  State<Myappview> createState() => _MyappviewState();
}

class _MyappviewState extends State<Myappview> {
  int count=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title:Text("MyappView",
          style:TextStyle(fontSize:25,color: Colors.white),),
        actions: [Icon(Icons.search_rounded,color: Colors.white,),
        ],
        ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 150,
              width:150,
              //padding:EdgeInsets.all(10),
              margin:EdgeInsets.all(10),
              child: Center(child: Text("My Container")),
              alignment: Alignment.bottomRight,
              //transform: Matrix4.rotationZ(0.1),
              //constraints: BoxConstraints.expand(height:90.0),
              decoration: BoxDecoration(
                  color: Colors.pinkAccent,
                border: Border.all(color: Colors.blueAccent,width: 5),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  new BoxShadow(color: Colors.greenAccent,offset: new Offset(6.0, 6.0))
                ]
              ),
            ),
            SizedBox(height: 10),
            Container(
              height:150,
              width:150,
              margin:EdgeInsets.all(10),
              child: Center(child:Text("My Container")),
              alignment:Alignment.bottomLeft ,
              decoration: BoxDecoration(
                color: Colors.greenAccent,
                border: Border.all(color: Colors.yellowAccent,width: 5),
                boxShadow: [
                  new BoxShadow(color: Colors.lightBlueAccent,offset: new Offset(6.0,6.0))
                ]
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 150,
              width:150,
              margin:EdgeInsets.all(10),
              child: Center(child:Text("My Container")),
              alignment: Alignment.bottomLeft,
              decoration: BoxDecoration(
                color: Colors.lightBlueAccent,
                border: Border.all(color: Colors.amberAccent,width: 5),
                boxShadow: [
                  new BoxShadow(color: Colors.lightGreenAccent,offset: new Offset(6.0,6.0))
                ]
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 150,
              width: 150,
              margin: EdgeInsets.all(10),
              child: Center(child:Text("My Container")),
              alignment: Alignment.bottomCenter,
              decoration: BoxDecoration(
                color: Colors.indigoAccent,
                border: Border.all(color: Colors.limeAccent,width: 5),
                boxShadow: [
                  new BoxShadow(color:Colors.cyanAccent,offset: new Offset(5.0,5.0))
                ]
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child:Icon(Icons.add),
        onPressed: () {
       setState(() {
         count ++;
       });
      },
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon:Icon(Icons.home),label:"Home"),
        BottomNavigationBarItem(icon:Icon(Icons.search_rounded),label:"Search_Rounded"),
        BottomNavigationBarItem(icon:Icon(Icons.account_circle),label:"Account_Circle"),
      ],),
      );
  }
}