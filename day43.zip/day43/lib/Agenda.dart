import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Agenda extends StatefulWidget {
  const Agenda({super.key});

  @override
  State<Agenda> createState() => _AgendaState();
}

class _AgendaState extends State<Agenda> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigoAccent,
        title: Text('Welcome to Australia',
        style: TextStyle(color: Colors.white),),
        actions: [Icon(Icons.flag_circle_outlined,
        color: Colors.deepOrange,)],
      ),
      backgroundColor: Colors.lightGreenAccent,
      body: Column(
        children: [
          Card(
            child: ListTile(
              leading: Icon(Icons.stadium_outlined),
              title: Text('India Tours Australia'),
              subtitle: Text('Light Theme'),
              onTap: (){
                Get.bottomSheet(
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.indigoAccent,
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Column(
                      children: [
                        ListTile(
                          leading: Icon(Icons.light_mode_outlined,
                          color: Colors.white,),
                          title: Text('Light Theme',
                          style: TextStyle(color: Colors.white),),
                          onTap: () {
                            Get.changeTheme(ThemeData.light());
                          },
                        ),
                        ListTile(
                          leading: Icon(Icons.dark_mode_outlined,
                          color: Colors.white,),
                          title: Text('Dark Theme',
                          style: TextStyle(color: Colors.white),),
                          onTap: () {
                            Get.changeTheme(ThemeData.dark());
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}