import 'package:day11/UserPage.dart';
import 'package:flutter/material.dart';

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  TextEditingController myController = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController mail = TextEditingController();
  TextEditingController registrationid = TextEditingController();
  TextEditingController pass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("Registration Portal",
        style: TextStyle(fontSize: 24,color:Colors.white)),
        actions: [Icon(Icons.app_registration_sharp,color:Colors.white)],
      ),
      body: SingleChildScrollView(
        child:Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  color:Colors.white,
                  border:Border.all(color:Colors.orangeAccent,width: 10),
                  borderRadius:BorderRadius.circular(8),
                  boxShadow: [
                    new BoxShadow(color: Colors.white60,spreadRadius: 5),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          controller: myController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "UserName",
                            hintText: "Enter Your userName",
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          controller: phone,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "Phone",
                            hintText: "Enter Your Contact Details",
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          controller: mail,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "EmailId",
                            hintText: "Enter Your Email Address",
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          controller: registrationid,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "Registration Id",
                            hintText: "Enter Your Registration Details",
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          controller: pass,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: "PassWord",
                            hintText: "Enter Your PassWord",
                          ),
                        ),
                      ),
                      ElevatedButton(onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=> Userpage()));
                      },
                          style: ButtonStyle(backgroundColor:WidgetStatePropertyAll(Colors.redAccent)),
                          child: Text("SignUp")),
                    ],
                  ),
                ),
                ),
              ],
          ),
          ),
        )
      );
  }
}
