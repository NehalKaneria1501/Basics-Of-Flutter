import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class Userpage extends StatefulWidget {
  const Userpage({super.key});

  @override
  State<Userpage> createState() => _UserpageState();
}

class _UserpageState extends State<Userpage> {
  int players=0;
  int score=0;
  int _counter=0;
  int _selectedIndex=0;
  void _incrementCounter(){
    setState(() {
      _counter++;
    });
  }
  static const List<Widget>_WidgetOptions = <Widget>[
    Text('Home Page', style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),),
    Text('Games', style: TextStyle(fontSize:24,fontWeight: FontWeight.bold ),),
    Text('Settings',style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex=index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.blue,
        title: Text("Tic Tac Toe Game",
        style: TextStyle(fontSize: 24,color: Colors.white),),
        actions: [Icon(Icons.account_circle,)],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.limeAccent),
                child: Text("Cross or Zero",style: TextStyle(color: Colors.black),)),
            ListTile(
              title: Text("Player-1"),
              subtitle: Text("Player-2"),
              leading: Icon(Icons.games),
            ),
            ListTile(
              title: Text("UserWin"),
              subtitle: Text("Computerized Player Lose"),
            ),
            ListTile(
              title: Text("Computerized Player Win"),
              subtitle: Text("UserLose"),
            ),
            ListTile(
              title: Text("Game Draw"),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height/7,
              width: MediaQuery.of(context).size.width/1,
              margin: EdgeInsets.all(8),
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                borderRadius:BorderRadius.circular(8),
                color: Colors.black12,
              ),
              child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'X-',
                        style: TextStyle(fontSize: 24,color: Colors.lightBlueAccent),
                      ),
                      TextSpan(
                        text: '-Zero',
                        style: TextStyle(fontSize: 24,color: Colors.redAccent),
                        recognizer: TapGestureRecognizer(),
                      ),
                      WidgetSpan(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Icon(Icons.currency_rupee_sharp),
                          ),
                      ),
                    ],
                  ),
              ),
            ),
            IconButton(
              icon:Icon(Icons.sports_esports_outlined),
              iconSize: 24,
                color: Colors.red,
                tooltip: "Increase Score on Each Move",
                onPressed: (){
                setState(() {
                  players += 1;
                  });
                  },
                  ),
            InkWell(
              splashColor: Colors.green,
              highlightColor: Colors.white60,
              child: Icon(Icons.scoreboard_outlined),
              onTap: (){
                setState(() {
                  score+= 0;
                });
              },
            ),
            Text(
                players.toString(),
              style: TextStyle(fontSize: 24),
            ),
            Text('$_counter',
            style:Theme.of(context).textTheme.bodyMedium ,)
                  ],
          )
        ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          tooltip: 'Increment',
          onPressed: _incrementCounter,
          ),
      bottomNavigationBar: BottomNavigationBar(
          items:[
            BottomNavigationBarItem(icon: Icon(Icons.home),label:"Home"),
            BottomNavigationBarItem(icon: Icon(Icons.games),label: "Games"),
            BottomNavigationBarItem(icon:Icon(Icons.settings),label: "Settings"),
          ],
        type: BottomNavigationBarType.fixed,
        currentIndex:_selectedIndex,
        selectedItemColor: Colors.black,
        iconSize: 24,
        onTap: _onItemTapped,
        elevation: 5,
      ),
    );
  }
}