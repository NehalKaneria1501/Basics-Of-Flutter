import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class Textfile extends StatefulWidget {
  const Textfile({super.key});

  @override
  State<Textfile> createState() => _TextfileState();
}

class _TextfileState extends State<Textfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: Text("RichedText",
          style: TextStyle(fontSize: 23,color: Colors.red),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration:BoxDecoration(
                color: Colors.deepPurpleAccent,
        ),
                child:Text("In Love At Ease",
                  style: TextStyle(fontSize: 22,color: Colors.lightGreen),),
              ),
            ListTile(
              title: Text("Love In Betterliving Inspiration"),
              subtitle: Text("Love To Inspire in Harmony"),
              leading: Icon(Icons.mail),
            ),
            Divider(
              height:0.7,
            ),
            ListTile(
              title: Text("Primary"),
            ),
            ListTile(
              title: Text("Social"),
            ),
            ListTile(
              title: Text("Important"),
            ),
          ],
        ),
      ),
        body:Column(
          children:[
            Container(
          height: 50,
          width: 50,
          padding: EdgeInsets.all(5),
          margin: EdgeInsets.all(5),
          child:Center(child:RichText(text:
          TextSpan(
            text: 'social media',
            style: TextStyle(fontSize: 20,color:Colors.white),
            children: [
              TextSpan(
                text: 'instagram',
                  style: TextStyle(fontSize: 20,color: Colors.black),
                recognizer:TapGestureRecognizer(),
              ),
              WidgetSpan(
                  child: Padding(padding:EdgeInsets.symmetric(horizontal: 5.0),
                  child: Icon(Icons.add),),
              )
            ]
          ),
          ),
          ),
          constraints:BoxConstraints.expand(height:85.0),
          decoration:BoxDecoration(
            color: Colors.lightBlueAccent,
            border:Border.all(color: Colors.transparent,width:5),
            borderRadius: BorderRadius.circular(7),
            boxShadow: [
              new BoxShadow(color: Colors.lightGreenAccent,offset:new Offset(5.0, 5.0))
            ],
          ),
        ),
        ],
        ),
    );
  }
}
