import 'package:day18/Tabs.dart';
import 'package:flutter/material.dart';

class Multabs extends StatefulWidget {
  const Multabs({super.key});

  @override
  State<Multabs> createState() => _MultabsState();
}

class _MultabsState extends State<Multabs> {
  var lists = List<String>.generate(11, (index) => "List:$index");

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.directions_bike_outlined)),
              Tab(icon: Icon(Icons.directions_car_filled_outlined)),
            ],
          ),
          backgroundColor: Colors.orangeAccent,
          title: const Text("Please tab upon camera+"),
          actions: const [Icon(Icons.add_a_photo_outlined)],
        ),
        body: TabBarView(
          children: [
            Container(
              child: Tabs(),
            ),
            Container(
              child: Column(
                children: [
                  Center(
                    child: Text(
                      "It is a second layout tab, which is responsible for taking pictures from your mobile",
                      style: TextStyle(fontSize: 35),
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: lists.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(lists[index]),
                          trailing: Container(
                            width: 60,
                            child: ElevatedButton(
                              child: Icon(
                                Icons.delete_outline_rounded,
                                color: Colors.grey,
                              ),
                              onPressed: () {
                                showSnackBar(context, index);
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void showSnackBar(BuildContext context, int index) {
    var deletedRecord = lists[index];
    setState(() {
      lists.removeAt(index);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Deleted $deletedRecord'),
        action: SnackBarAction(
          label: "Undo",
          onPressed: () {
            setState(() {
              lists.insert(index, deletedRecord);
            });
          },
        ),
      ),
    );
  }
}