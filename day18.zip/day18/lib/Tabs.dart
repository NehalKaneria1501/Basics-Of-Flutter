import 'package:flutter/material.dart';

class Tabs extends StatefulWidget {
  const Tabs({super.key});

  @override
  State<Tabs> createState() => _TabsState();
}

class _TabsState extends State<Tabs> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orangeAccent,
        title: Text("Please tabp upon +sign"),
        actions: [Icon(Icons.add)],
      ),
      body: Container(
        child: Center(
          child: Text("It is a contact tab,which is responsible for displaying the contacts stored in your mobile",
          style: TextStyle(fontSize: 32)),
        ),
      ),
    );
  }
}
