import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Selectedoptional extends StatefulWidget {
  const Selectedoptional({super.key});

  @override
  State<Selectedoptional> createState() => _SelectedoptionalState();
}

class _SelectedoptionalState extends State<Selectedoptional> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurpleAccent,
        title: Text("Selected Option Alert Dialog"),
        actions: [Icon(Icons.add_alert_outlined)],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: () async {
              _asyncSimpleDialog(context);
            //  print("Selected Product is $prodName");
            },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(30,10,30,10),
                  child: Text("Show Alert",
                  style: TextStyle(fontSize: 20,color: Colors.red),),
                ),
            )
          ],
        ),
      ),
    );
  }
}
enum Product{Apple,Samsung,Oppo,Redmi}
Future<Product?>_asyncSimpleDialog(BuildContext context)async{
  return await showDialog <Product>(
    context: context,
    barrierDismissible: true,
    builder: (context){
      return SimpleDialog(
        title: Text("Select Product"),
        children: <Widget> [
          SimpleDialogOption(
            onPressed: (){
              Navigator.pop(context, Product.Apple);
            },
            child: Text("Apple"),
          ),
          SimpleDialogOption(
            onPressed: (){
              Navigator.pop(context, Product.Samsung);
            },
            child: Text("Samsung"),
          ),
          SimpleDialogOption(
            onPressed: (){
              Navigator.pop(context, Product.Oppo);
            },
            child: Text("Oppo"),
          ),
          SimpleDialogOption(
            onPressed: (){
              Navigator.pop(context, Product.Redmi);
            },
            child: Text("Redmi"),
          )
        ],
      );
    }
  );
}