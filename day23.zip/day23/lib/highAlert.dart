import 'package:flutter/material.dart';

class Highalert extends StatefulWidget {
  const Highalert({super.key});

  @override
  State<Highalert> createState() => _HighalertState();
}

class _HighalertState extends State<Highalert> {
  TextEditingController _textEditingController=TextEditingController();
  _displayDialog(BuildContext context)async{
    return showDialog(
        context: context, builder: (context){
          return AlertDialog(
            title: Text('TextField AlertDemo'),
            content: TextField(
              controller: _textEditingController,
              decoration: InputDecoration(
                hintText: "TextField in Dialog"
              ),
            ),
            actions: <Widget> [
              new ElevatedButton(onPressed: (){
                Navigator.of(context).pop();
              },
                  child: new Text("Submit"),
              ),
            ],
          );
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurpleAccent,
        title: Text("Show Alert"),
        actions: [Icon(Icons.add_alert_outlined)],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20,12,20,12),
          child: ElevatedButton(
              child: Text("Show Alert",
              style: TextStyle(fontSize: 20,
                  color: Colors.red),
              ),
            onPressed: ()=>_displayDialog(context
              ),
          ),
        ),
      ),
    );
  }
}
