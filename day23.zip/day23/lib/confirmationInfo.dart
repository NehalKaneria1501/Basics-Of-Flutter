import 'package:flutter/material.dart';

class Confirmationinfo extends StatefulWidget {
  const Confirmationinfo({super.key});

  @override
  State<Confirmationinfo> createState() => _ConfirmationinfoState();
}

class _ConfirmationinfoState extends State<Confirmationinfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurpleAccent,
        title: Text("Confirmation AlertDialog"),
        actions: [Icon(Icons.add_alert_outlined)],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () async {
                _asyncConfirmDialog(context);
               // print("Confirm Action $action" );
              },
              child: Text(
                "Show Alert",
                style: TextStyle(fontSize: 20.0),),
            //  padding: EdgeInsets.fromLTRB(30.0,10.0,30.0,10.0),
             // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
             // color: Colors.green,
            ),
          ],
        ),
      ),
    );
  }
}
enum ConfirmAction { Cancel, Accept}
Future<Future<ConfirmAction?>> _asyncConfirmDialog(BuildContext context) async {
  return showDialog<ConfirmAction>(
    context: context,
    barrierDismissible: false, // user must tap button for close dialog!
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Delete This Contact?'),
        content: const Text(
            'This will delete the contact from your device.'),
        actions: <Widget>[
          ElevatedButton(
            child: const Text('Cancel'),
            onPressed: () {
              Navigator.of(context).pop(ConfirmAction.Cancel);
            },
          ),
          ElevatedButton(
            child: const Text('Delete'),
            onPressed: () {
              Navigator.of(context).pop(ConfirmAction.Accept);
            },
          )
        ],
      );
    },
  );
}