import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int apple=0;
  int count=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Black Friday Sale",
        style: TextStyle(fontSize: 24,color: Colors.white),),
        actions: [Icon(Icons.account_circle,color: Colors.white,)],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
                decoration: BoxDecoration(color: Colors.blueAccent),
              child: Text("Apple Mega Sale",
                style: TextStyle(fontSize: 20,color:Colors.white),),
            ),
            ListTile(
              title: Text("Each And Every Apple Products Mega Discount Sale"),
              subtitle: Text("30% Discount upon Iphones And 25% Discount upon MacBook"),
              leading: Icon(Icons.apple_sharp),
            ),
            Divider(
              height: 1.0
            ),
            ListTile(
              title: Text("Iphone 15 Pro Max"),
            ),
            ListTile(
              title: Text("Iphone 16 Pro Max"),
            ),
            ListTile(
              title: Text("Apple MacBook Pro M3 Max"),
            ),
            ListTile(
              title: Text("Apple 16 MacBook Pro M4 Max"),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 200,
              width: 50,
              margin: EdgeInsets.all(10),
              padding: EdgeInsets.all(10),
              child: Center(child: Text("Bumper Discount On Apple Products",style: TextStyle(fontSize: 20,color:Colors.black)),
              ),
                constraints: BoxConstraints.expand(height: 170),
                decoration: BoxDecoration(
                    color: Colors.limeAccent,border: Border.all(color:Colors.teal),
                    borderRadius: BorderRadius.circular(7),
                    boxShadow: [new BoxShadow(color: Colors.blue,offset: Offset(7.0, 7.0))],
                ),
              ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  margin: EdgeInsets.all(10),
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color:Colors.redAccent,
                  ),
                  child: Text("ChrisMax Offer",style: TextStyle(fontSize: 17,color: Colors.white)),
                ),
                SizedBox(
                  height: 5.0,
                ),
                IconButton(
                  icon: Icon(Icons.apple_sharp),
                  iconSize:20,
                  color:Colors.black,
                  tooltip:'MacOs',
                  onPressed: (){
                    setState(() {
                      apple+=1;
                    });
                    Text('apple:$apple');
                  },
                ),
                IconButton(
                  icon: Icon(Icons.phone_iphone),
                  iconSize:20,
                  color:Colors.black,
                  tooltip:'MacOs',
                  onPressed: (){
                    setState(() {
                      apple+=1;
                    });
                    Text('apple:$apple');
                  },
                ),
                InkWell(
                  splashColor:Colors.white70,
                  highlightColor: Colors.black12,
                  child: Icon(Icons.laptop_mac),
                  onTap:(){
                    setState(() {
                      apple+=1;
                    });
                  },
                ),
                Text(
                  apple.toString(),
                  style: TextStyle(fontSize: 25),
              )
            ],
            )
        ],
        ),
      ),
        floatingActionButton: FloatingActionButton(onPressed: (){
          setState(() {
            count++;
          });
        },
          child:Icon(Icons.add),
          backgroundColor: Colors.lightBlueAccent,
          foregroundColor: Colors.white,
        ),
        bottomNavigationBar: BottomNavigationBar(
            items:[
              BottomNavigationBarItem(icon: Icon(Icons.home),label: "Home"),
              BottomNavigationBarItem(icon: Icon(Icons.search_rounded),label: "Search_rounded"),
              BottomNavigationBarItem(icon: Icon(Icons.settings),label:"Settings"),
            ]),
);
  }
}