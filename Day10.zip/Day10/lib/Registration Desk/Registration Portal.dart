import 'package:day10/Home%20Screen.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class RegistrationForm extends StatefulWidget {
  const RegistrationForm({super.key});

  @override
  State<RegistrationForm> createState() => _RegistrationFormState();
}

class _RegistrationFormState extends State<RegistrationForm> {
  TextEditingController myController=TextEditingController();
  TextEditingController phone=TextEditingController();
  TextEditingController mail=TextEditingController();
  TextEditingController branch_name=TextEditingController();
  TextEditingController customer_id=TextEditingController();
  TextEditingController product_id=TextEditingController();
  TextEditingController password=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Black Friday Sale",
        style: TextStyle(fontSize: 24,color: Colors.white70)),
        actions: [Icon(Icons.store_mall_directory_outlined,color: Colors.black26)],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height/15,
              width: MediaQuery.of(context).size.width,
              margin: EdgeInsets.all(10),
              padding: EdgeInsets.all(10),
              alignment: Alignment(0, 1),
              constraints:BoxConstraints.expand(height:60),
              decoration: BoxDecoration(
                color: Colors.indigoAccent,
                border: Border.all(color:Colors.lightBlue,width: 5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blueGrey,
                  ),
                ],
              ),
              child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'Sale On Iphone',
                        style: TextStyle(fontSize: 19,color: Colors.redAccent),
                      ),
                      TextSpan(
                        text: '-Sale On MacBook',
                        style: TextStyle(fontSize: 20,color: Colors.greenAccent),
                        recognizer: TapGestureRecognizer(),
                      ),
                      WidgetSpan(
                          child: Padding(
                              padding:EdgeInsets.symmetric(horizontal: 1.0),
                            child: Icon(Icons.login),
                          ),
                      ),
                    ],
                  ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  controller: myController,
                decoration: InputDecoration(
                  border:OutlineInputBorder(),
                  labelText: 'UserName',
                  hintText: "Enter Your User Name",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  controller:phone,
                  maxLength: 10,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Contact Detail',
                    hintText: "Enter Your Contact Details",
                  ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: mail,
                decoration: InputDecoration(
                  border:OutlineInputBorder(),
                  labelText: 'EmailId',
                  hintText: "Enter Your Email Address",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  controller: branch_name,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'branch_name',
                  hintText: "Enter Your Branch Name",
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  controller: product_id,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'product_id',
                      hintText: "Enter Your Product Details",
                    ),
                  ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  controller:password,
                maxLength: 8,
                decoration:InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'PassWord',
                  hintText: "Enter Your PassWord",
                ) ,
              ),
            ),
            ElevatedButton(onPressed:(){
              Navigator.push(context, MaterialPageRoute(builder:(context)=>HomeScreen()));
            },
                style: ButtonStyle(backgroundColor: WidgetStatePropertyAll(Colors.redAccent)),
            child:Text("SignUp",style: TextStyle(color: Colors.white),)),
          ],
        ),
      ),
    );
  }
}