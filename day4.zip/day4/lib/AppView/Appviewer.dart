import 'package:flutter/material.dart';
class Appviewer extends StatefulWidget {
  const Appviewer({super.key});
  @override
  State<Appviewer> createState() => _AppviewerState();
}
class _AppviewerState extends State<Appviewer> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightGreen,
        title: Text("AppDesk",
          style: TextStyle(fontSize:25,color: Colors.white),),
        actions: [Icon(Icons.search_rounded,color: Colors.white,),],
      ),
        drawer:Drawer(
          child: ListView(
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  color:Colors.blue
                  ),
                    child:Text("Welcome to my first apk",
                    style:TextStyle(color:Colors.white),
                  ),
                ),
              ListTile(
                title:Text('1'),
              ),
              ListTile(
                title:Text("It's personal file"),
                subtitle:Text("It's my folder file"),
                leading:Icon(Icons.phone),
              ),
              Divider(
                height:1.0,
              ),
              ListTile(
                title:Text("Have a nice day with bliss epic"),
              )
            ],
          ),
        ),
        body: Center(
        child: Text("Thank you visit again"),
    ),
      floatingActionButton: FloatingActionButton(onPressed:(){},child:Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon:Icon(Icons.home),label:"home"),
        BottomNavigationBarItem(icon:Icon(Icons.search_rounded),label:"search"),
        BottomNavigationBarItem(icon:Icon(Icons.account_circle),label:"account_circle"),
      ],),
      );
  }
}