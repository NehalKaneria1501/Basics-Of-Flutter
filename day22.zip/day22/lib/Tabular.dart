import 'package:flutter/material.dart';

class Tabular extends StatefulWidget {
  const Tabular({super.key});

  @override
  State<Tabular> createState() => _TabularState();
}

class _TabularState extends State<Tabular> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purpleAccent,
        title: Text('Tables'),
        actions: [Icon(Icons.table_view_outlined)],
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: <Widget> [
              Container(
                margin: EdgeInsets.all(20),
                child: Table(
                  defaultColumnWidth: FixedColumnWidth(20),
                  border: TableBorder.all(
                    color: Colors.black,
                    style: BorderStyle.solid,
                    width: 0,
                  ),
                  children: [
                    TableRow(
                      children: [
                        Column(
                          children: [
                            Text("Website",style: TextStyle(fontSize: 10),),],),
                        Column(
                          children: [
                            Text("Tutorial",style: TextStyle(fontSize: 10),)],),
                        Column(
                          children: [
                            Text("Review",style: TextStyle(fontSize: 10),),],),
                      ],),
                    TableRow(
                      children: [
                        Column(
                          children: [Text("Javatpoint")]
                        ),
                            Column(
                              children: [Text("MySQL")],
                            ),
                        Column(
                          children: [Text("5*")],
                        ),
                      ],
                    ),
                    TableRow(
                      children: [
                        Column(
                          children: [
                            Text("Javatpoint")],
                        ),
                        Column(
                          children: [
                            Text("ReactJS")
                          ],
                        ),
                        Column(
                          children: [
                            Text("5*")
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
        ),
                ],
            ),
        ),
      ),
    );
  }
}