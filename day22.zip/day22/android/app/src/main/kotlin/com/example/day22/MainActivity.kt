package com.example.day22

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
