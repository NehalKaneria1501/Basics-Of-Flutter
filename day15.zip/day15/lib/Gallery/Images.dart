import 'package:flutter/material.dart';

class ImagesDemo extends StatefulWidget {
  const ImagesDemo({super.key});

  @override
  State<ImagesDemo> createState() => _ImagesDemoState();
}

class _ImagesDemoState extends State<ImagesDemo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("AkshardhaM"),
        actions: [Icon(Icons.mode_of_travel_rounded)],
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            Container(
              height: 200,
              width: 200,
              color: Colors.transparent,
              child: Image.asset("assets/2024_11.jpg")),
            Text('Baps Swaminarayan AkshardhaM a landmark of Hindu architecture',
            style: TextStyle(fontSize: 14)),
            Image.asset("assets/2024_11.jpg",),
            Text('Akshardham Abhivandanam',
            style: TextStyle(fontSize: 14)),
            FadeInImage.assetNetwork(
                placeholder:'assets/Images/2024_11.jpg',
                image: 'https://static.javatpoint.com/tutorial/flutter/images/flutter-creating-android-platform-specific-code3.png',
            height: 200,
            width: 200),
            Text('Akshardham within us',
            style: TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }
}