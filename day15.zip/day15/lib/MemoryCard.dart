import 'package:flutter/material.dart';

class Memorycard extends StatefulWidget {
  const Memorycard({super.key});

  @override
  State<Memorycard> createState() => _MemorycardState();
}

class _MemorycardState extends State<Memorycard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("TransparentImg",
        style: TextStyle(fontSize: 24,color: Colors.black)),
        actions: [Icon(Icons.account_box_outlined)],
      ),
      body: Center(
        child: Column(
          children: <Widget> [
          ],
        ),
      ),
    );
  }
}
