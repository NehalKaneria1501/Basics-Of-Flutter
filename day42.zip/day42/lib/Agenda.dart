import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart';
import 'package:image_picker/image_picker.dart';

class Agenda extends StatefulWidget {
  const Agenda({super.key});

  @override
  State<Agenda> createState() => _AgendaState();
}

class _AgendaState extends State<Agenda> {
  final ImagePickerController imagePickerController = Get.put(ImagePickerController());
  final LoginController loginController = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigoAccent,
        title: const Text('BAPS Fuldolotsav-ANZ', style: TextStyle(color: Colors.white)),
        actions: const [
          Icon(Icons.format_color_fill_outlined, color: Colors.deepOrange)
        ],
      ),
      body: Obx(() {
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: CircleAvatar(
                radius: 25,
                backgroundImage: imagePickerController.imagePath.isNotEmpty
                    ? FileImage(File(imagePickerController.imagePath.toString()))
                    : null,
              ),
            ),
            TextButton(
              onPressed: () {
                imagePickerController.getImage();
              },
              child: Text('Choose From Gallery'),
            ),
            TextFormField(
              controller: loginController.emailController.value,
              decoration: InputDecoration(
                hintText: 'Enter your email id',
              ),
            ),
            TextFormField(
              controller: loginController.passwordController.value,
              decoration: InputDecoration(
                hintText: 'Enter your password',
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Obx(() {
              return InkWell(
                onTap: () {
                  loginController.loginApi();
                },
                child: loginController.loading.value
                    ? CircularProgressIndicator()
                    : Container(
                  height: 25,
                  color: Colors.blueGrey,
                  child: Center(
                    child: Text('Login'),
                  ),
                ),
              );
            }),
          ],
        );
      }),
    );
  }
}

class LoginController extends GetxController {
  final emailController = TextEditingController().obs;
  final passwordController = TextEditingController().obs;
  var loading = false.obs;

  void loginApi() async {
    loading.value = true;
    Map<String, String> data = {
      'email': emailController.value.text,
      'password': passwordController.value.text,
    };

    try {
      final response = await post(
        Uri.parse('https://reqres.in/api/login'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(data),
      );

      var responseData = jsonDecode(response.body);
      print(responseData);

      if (response.statusCode == 200) {
        loading.value = false;
        Get.snackbar('Login Successful', 'Congratulations');
      } else {
        loading.value = false;
        Get.snackbar('Login Failed', responseData['error']);
      }
    } catch (e) {
      loading.value = false;
      Get.snackbar('Exception', e.toString());
    }
  }
}

class ImagePickerController extends GetxController {
  RxString imagePath = ''.obs;

  Future getImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      imagePath.value = image.path;
    }
  }
}
