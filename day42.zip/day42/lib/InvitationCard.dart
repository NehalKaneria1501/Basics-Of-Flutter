import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Invitationcard extends StatefulWidget {
  const Invitationcard({super.key});

  @override
  State<Invitationcard> createState() => _InvitationcardState();
}

class _InvitationcardState extends State<Invitationcard> {
  final ThemeController themeController = Get.put(ThemeController());
  final CounterController controller = Get.put(CounterController());
  final CanadaController canadaController = Get.put(CanadaController());
  final SwitchController switchController = Get.put(SwitchController());
  final UniversityListController universityListController = Get.put(UniversityListController());

  int x = 20;
  int counter = 0;

  @override
  void initState() {
    super.initState();
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      setState(() {
        x++;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    print('build');
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigoAccent,
        title: const Text('BAPS Asia-Pacific', style: TextStyle(color: Colors.white)),
        actions: const [Icon(Icons.flag, color: Colors.deepOrange)],
      ),
      backgroundColor: Colors.blueGrey,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Card(
              child: ListTile(
                title: const Text('Baps Australia'),
                subtitle: const Text('Baps Melbourne & Sydney'),
                leading: const Icon(Icons.landscape_outlined, color: Colors.white),
                onTap: () {
                  Get.defaultDialog(
                    title: 'Most Tourist Attractions in Australia for visitors',
                    contentPadding: const EdgeInsets.all(20),
                    confirm: TextButton(
                      onPressed: () => Get.back(),
                      child: const Text('Ok', style: TextStyle(color: Colors.lightGreenAccent)),
                    ),
                    cancel: TextButton(
                      onPressed: () {},
                      child: const Text('Cancel', style: TextStyle(color: Colors.red)),
                    ),
                    content: const Column(
                      children: [
                        Text('Great Barrier Reef', style: TextStyle(color: Colors.cyanAccent)),
                        Text('Uluru', style: TextStyle(color: Colors.cyanAccent)),
                        Text('Marvel Stadium', style: TextStyle(color: Colors.cyanAccent)),
                        Text('Gold Coast', style: TextStyle(color: Colors.cyanAccent)),
                        Text('Opera House', style: TextStyle(color: Colors.cyanAccent)),
                      ],
                    ),
                  );
                },
              ),
            ),
            Obx(() => IconButton(
              icon: Icon(
                themeController.isDarkMode.value
                    ? Icons.light_mode
                    : Icons.dark_mode,
              ),
              onPressed: () => themeController.toggleTheme(),
            )),
            TextButton(
                onPressed: () => Get.toNamed('/Agenda'),
                child: const Text('Next=>')
            ),
            TextButton(
                onPressed: () => Get.toNamed('/Welcome', arguments: {
                  'Fiji', 'Papua New Guinea', 'New Zealand'
                }),
                child: const Text('<=Back')),
            Container(
              height: Get.height * 0.1,
              width: Get.width * 0.5,
              color: Colors.lightBlueAccent,
              child: const Center(
                child: Text('Great Ocean Road', style: TextStyle(color: Colors.white)),
              ),
            ),
            const SizedBox(height: 5),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ListTile(
                  title: Text('message'.tr, style: const TextStyle(color: Colors.lightGreenAccent)),
                  subtitle: Text('name'.tr, style: const TextStyle(color: Colors.lightGreenAccent)),
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    OutlinedButton(
                      onPressed: () => Get.updateLocale(const Locale('en', 'US')),
                      child: const Text('English'),
                    ),
                    const SizedBox(width: 20),
                    OutlinedButton(
                      onPressed: () => Get.updateLocale(const Locale('fr', 'CA')),
                      child: const Text('Francis'),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text(x.toString(), style: const TextStyle(fontSize: 23)),
                Text(counter.toString(), style: const TextStyle(fontSize: 23)),
                Obx(() => Text(controller.counter.toString(), style: const TextStyle(fontSize: 23))),
                Container(
                  height: 300,
                  child: ListView.builder(
                    itemCount: 25,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(index.toString()),
                      );
                    },
                  ),
                ),
                Obx(() => Text(controller.counter.toString(), style: const TextStyle(fontSize: 23))),
                Obx(() => Container(
                  height: 200,
                  width: 200,
                  color: Colors.cyanAccent.withOpacity(canadaController.opacity.value),
                )),
                Obx(() => Slider(
                  value: canadaController.opacity.value,
                  onChanged: (value) => canadaController.setOpacity(value),
                )),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Notification'),
                    Switch(value: switchController.notification.value, onChanged: (value) {
                      switchController.setNotification(value);
                      setState(() {});
                    })
                  ],
                ),
    SizedBox(
    height: 200,
    child: ListView.builder(
    itemCount: universityListController.uniList.length,
    itemBuilder: (context, index) {
    return Card(
    child: ListTile(
    onTap: () {
    setState(() {
    universityListController.toggleFavorite(index);
    });
    },
    title: Text(universityListController.uniList[index]),
    trailing: Icon(
    universityListController.selectedUniversities.contains(universityListController.uniList[index])
    ? Icons.favorite
        : Icons.favorite_border,color: Colors.red,
    ),
    ),
    );
    },
    ),
    )
  ],
                  ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            x++;
            counter++;
          });
          controller.incrementCounter();
        },
      ),
    );
  }
}
class UniversityListController extends GetxController {
  List<String> uniList = ['UofMelbourne', 'UofSydney', 'OfQueensland', 'UofAdelaide'];
  RxList<String> selectedUniversities = <String>[].obs;

  void toggleFavorite(int index) {
    String university = uniList[index];
    if (selectedUniversities.contains(university)) {
      selectedUniversities.remove(university);
    } else {
      selectedUniversities.add(university);
    }
  }
}

class SwitchController extends GetxController {
  RxBool notification = false.obs;

  void setNotification(bool value) {
    notification.value = value;
    print(notification.value);
  }
}
class CanadaController extends GetxController {
  RxDouble opacity = 0.4.obs;
  void setOpacity(double value) {
    opacity.value = value;
  }
}
class CounterController extends GetxController {
  RxInt counter = 1.obs;
  void incrementCounter() {
    counter.value++;
  }
}
class ThemeController extends GetxController {
  var isDarkMode = false.obs;
  void toggleTheme() {
    isDarkMode.value = !isDarkMode.value;
    Get.changeThemeMode(isDarkMode.value ? ThemeMode.dark : ThemeMode.light);
  }
}
class Languages extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
    'en_US': {
      'message': 'SATPURUSH HH Mahant Swami Maharaj in Canada',
      'name': 'BAPS North America'
    },
    'fr_CA': {
      'message': 'SATPURUSH HH Mahant Swami Maharaj au Canada',
      'name': 'BAPS Amérique du Nord'
    }
  };
}