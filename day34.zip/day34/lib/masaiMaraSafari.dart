import 'dart:io';

import 'package:day34/Nile.dart';
import 'package:day34/createNewAccount.dart';
import 'package:day34/eA25.dart';
import 'package:flutter/material.dart';

class Masaimarasafari extends StatefulWidget {
  const Masaimarasafari({super.key});

  @override
  State<Masaimarasafari> createState() => _MasaimarasafariState();
}

class _MasaimarasafariState extends State<Masaimarasafari> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: Image.asset(
                "assets/Screenshot 2025-01-01 163012.jpg",
              scale: 0.3,),
            ),
            SizedBox(
              height: 50,
            ),
            Padding(
              padding: const EdgeInsets.all(38.0),
              child: Column(
                children: [
                  TextFormField(
                    decoration: InputDecoration(
                      border: UnderlineInputBorder(),
                      hintText: "Email",
                    ),
                  ),
              TextFormField(
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  hintText: "Password",
                ),
              ),
                  Text("Sign in using fingerprint"),
                  SizedBox(
                    height: 10,
                  ),
                  TextButton(
                    style: ButtonStyle(
                      backgroundColor: WidgetStatePropertyAll<Color>(
                        Colors.greenAccent,
                      ),
                    ),
                      onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>Createnewaccount()));
                  },
                      child: Container(
                        width: 350,
                        child: Text("Sign in",
                          style: TextStyle(
                            color: Colors.white
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text("Or sign in with",
                  textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(
                        Icons.facebook_outlined,
                      ),
                      Icon(
                          Icons.abc_outlined,
                      ),
                      Icon(
                          Icons.account_box_outlined,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 35,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        style: ButtonStyle(
                          backgroundColor: WidgetStatePropertyAll<Color>(Colors.transparent)
                        ),
                          onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Createnewaccount()));
                      },
                        child:Text('Sign up',
                        textAlign: TextAlign.left,
                          textDirection: TextDirection.ltr,
                        ),
                        ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextButton(
                            style: ButtonStyle(
                              backgroundColor: WidgetStatePropertyAll<Color>(Colors.transparent)
                            ),
                              onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>Nile()));
                          },
                              child: Text('Forgot Password?',
                              textAlign: TextAlign.right,
                              )
                          ),
                        ],
                      )
                    ],
                  ),
    ],
              ),
      ),
    ],
    ),
      ),
            );
  }
}