import 'dart:convert';
import 'package:day34/Model/LoginModel.dart';
import 'package:day34/Nile.dart';
import 'package:day34/masaiMaraSafari.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Createnewaccount extends StatefulWidget {
  const Createnewaccount({super.key});

  @override
  State<Createnewaccount> createState() => _CreatenewaccountState();
}

class _CreatenewaccountState extends State<Createnewaccount> {
  TextEditingController email = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController pass = TextEditingController();

  bool isSwitched = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/Screenshot 2025-01-01 173318.jpg',
              scale: 0.4,
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.all(28.0),
              child: Column(
                children: [
                  TextFormField(
                    controller: name,
                    decoration: InputDecoration(
                      border: UnderlineInputBorder(),
                      hintText: "Name",
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  TextFormField(
                    controller: email,
                    decoration: InputDecoration(
                      border: UnderlineInputBorder(),
                      hintText: "Email",
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  TextFormField(
                    controller: pass,
                    decoration: InputDecoration(
                      border: UnderlineInputBorder(),
                      hintText: "Password",
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Switch(
                        value: isSwitched,
                        onChanged: (value) {
                          setState(() {
                            isSwitched = value;
                          });
                        },
                        activeColor: Colors.green,
                      ),
                      Text(
                          "I accept the policy and terms"
                      )
                    ],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  TextButton(
                    style: ButtonStyle(
                      backgroundColor:
                      WidgetStateProperty.all
                      <
                          Color
                      >
                        (
                          Colors.green
                      ),
                    ),
                    onPressed: () {
                      fetchAlbum(
                          email.text.toString(),
                          pass.text.toString());
                      print(
                          "Login=============>>>>>>"
                      );
                       Navigator.push(
                         context, MaterialPageRoute(
                           builder: (
                               context
                               ) => Nile(
                           )
                       ),
                       );
                    },
                    child: Text(
                      "Sign Up",
                      style: TextStyle(
                          color: Colors.white
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                      "Or sign up with",
                      textAlign: TextAlign.center
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                          Icons.facebook_outlined
                      ),
                      SizedBox(
                          width:15
                      ),
                      Icon(
                          Icons.abc_outlined
                      ),
                      SizedBox(
                          width: 15
                      ),
                      Icon(
                          Icons.account_box_outlined
                      ),
                    ],
                  ),
                  SizedBox(
                      height: 20
                  ),
                  Text(
                      "Already have an account?"
                  ),
                  TextButton(
                    style: ButtonStyle(
                      backgroundColor:
                      WidgetStateProperty.all
                      <
                          Color
                      >
                        (
                          Colors.transparent
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (
                                context
                                ) => Masaimarasafari()
                        ),
                      );
                    },
                    child: Text(
                      'Sign in',
                      style: TextStyle(color: Colors.green
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  Future<LoginModel> fetchAlbum(String email, String pass) async {
    final response = await http.get(
        Uri.parse(
            "https://reqres.in/api/login"
        )
    );
    if (
    response.statusCode == 200
    )
    {
      print(
          "Login Success"
      );
    LoginModel loginModel = LoginModel.fromJson(
        jsonDecode(
            response.body
        )
    );
    print(
        "response====>>>> ${
            response.body
        }"
    );
      return loginModel;
    }
    else {
      throw Exception(
          'Failed to load album'
      );
    }
  }
} 