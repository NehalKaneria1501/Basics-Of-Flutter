import 'package:day34/createNewAccount.dart';
import 'package:day34/masaiMaraSafari.dart';
import 'package:flutter/material.dart';

class Gogreen extends StatefulWidget {
  const Gogreen({super.key});

  @override
  State<Gogreen> createState() => _GogreenState();
}

class _GogreenState extends State<Gogreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: Image.asset("assets/Screenshot 2025-01-01 154405.jpg",
              scale: 0.1,
              width: MediaQuery.of(context).size.width/1,
              ),
            ),
            SizedBox(
              height: 45,
            ),
            TextButton(
              style: ButtonStyle(
                backgroundColor: WidgetStatePropertyAll<Color>(Colors.greenAccent)
              ),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context)=>Masaimarasafari()));
            },
                child: Container(
                  width: 350,
                  padding: EdgeInsets.all(1),
                  child: Text('Sign in',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                    textAlign: TextAlign.center,
                  ),
                ),
            ),
            SizedBox(
              height: 5,
            ),
            TextButton(
              style: ButtonStyle(
                backgroundColor: WidgetStatePropertyAll<Color>(Colors.grey),
              ),
                onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>Createnewaccount()));
            },
                child:Container(
                  width: 350,
                  child: Text('Create New Account',
                  style: TextStyle(
                    color: Colors.black87
                  ),
                    textAlign: TextAlign.center,
                  ),
                ),
            ),
          ],
        ),
      ),
    );
  }
}
