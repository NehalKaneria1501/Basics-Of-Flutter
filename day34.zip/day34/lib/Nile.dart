import 'package:flutter/material.dart';

class Nile extends StatefulWidget {
  const Nile({super.key});

  @override
  State<Nile> createState() => _NileState();
}

class _NileState extends State<Nile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
