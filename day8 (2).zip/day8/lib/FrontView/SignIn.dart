import 'package:flutter/material.dart';

class Signin extends StatefulWidget {
  const Signin({super.key});

  @override
  State<Signin> createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  TextEditingController myController = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController pass = TextEditingController();
  int Count = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Apc",
          style: TextStyle(fontSize: 24, color: Colors.white),),
        actions: [Icon(Icons.login, color: Colors.white)],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.limeAccent,
              ),
              child: Text("Welcome to Annual Day",
                style: TextStyle(fontSize: 26.13, color: Colors.redAccent),
              ),
            ),
            ListTile(
              title: Text("Kalavad Road"),
              subtitle: Text("University Road, Mavdi Road"),
              leading: Icon(Icons.home),
            ),
            Divider(
              height: 1.0,
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(children: <Widget>[
          Padding(
            padding: EdgeInsets.all(15),
            child: TextField(
              controller: myController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'User Name',
                hintText: 'Enter Your Name',
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: email,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Email Id',
                hintText: 'Enter Your EmailId',
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              maxLength: 8,
              controller: pass,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'PassWord',
                hintText: 'Enter Your Password',
              ),
            ),
          ),
          ElevatedButton(onPressed: () {
            alertDialog();
          },
              child: Text("SignUp")),
        ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed:(){
            setState(() {
              Count ++;
            });
          }),
    );
  }
  Future alertDialog() {
    return showDialog(context: context,
        builder: (context){
      return AlertDialog(
        title: Text("AlertMessage"),
        content: Text(myController.text),
        actions: [
          ElevatedButton(onPressed: (){
            Navigator.of(context).pop();
          },
          child: Text("Ok"),),
        ],
      );
      }
    );
}
}