import 'package:day31/TM.dart';
import 'package:flutter/material.dart';

class Yoovi extends StatefulWidget {
  const Yoovi({super.key});

  @override
  State<Yoovi> createState() => _YooviState();
}

class _YooviState extends State<Yoovi> {
  final _formKey=GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepOrangeAccent,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 370,
              ),
             Center(
               child: Container(
                height: MediaQuery.of(context).size.height/3.3,
                width: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  color: Colors.white
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 20,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          border: UnderlineInputBorder(),
                          prefixIcon: Icon(Icons.account_box_outlined),
                          hintText: "User-Name...",
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          border: UnderlineInputBorder(),
                          prefixIcon: Icon(Icons.mail_outline_outlined),
                          hintText: "E-mail...",
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.password_outlined),
                          hintText: "Password...",
                        ),
                      ),
                          ],
                        ),
                      )
               ),
                  ),
               SizedBox(
                 height: 40,
               ),
               InkWell(
               onTap: (){
                 Navigator.push(context, MaterialPageRoute(builder: (context)=>Tm()));
                   },
                 child: Container(
                   height: 55,
                   width: 400,
                   decoration: BoxDecoration(
                   borderRadius: BorderRadius.circular(18),
                     color: Colors.indigo,
                   ),
               child: Center(
                  child: Text("Login",
                     style: TextStyle(fontSize: 21,color: Colors.white),),
                   ),
               ),
         ),
         SizedBox(
           height: 25,
         ),
         RichText(
             text:TextSpan(
               text: 'SignUp if doesnot have account'
             ),
         ),
      ],
    ),
    ),
      ),
             );
  }
}