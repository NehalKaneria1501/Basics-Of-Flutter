import 'package:flutter/material.dart';

class Tm extends StatefulWidget {
  const Tm({super.key});

  @override
  State<Tm> createState() => _TmState();
}

class _TmState extends State<Tm> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text("TM",
        style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}
