import 'package:day33/hakunaMatanaMSMAfrica.dart';
import 'package:flutter/material.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purpleAccent,
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 200,
            ),
            Center(
              child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                text: 'SIGN UP\n',
                style: TextStyle(
                  color: Colors.orangeAccent,
                  fontSize: 25
                ),
                  ),
                      TextSpan(
                        text: 'TO CONTINUE',
                        style: TextStyle(
                            color: Colors.white,
                        fontSize: 25
                        ),
                      ),
              ],
                  ),
                textAlign: TextAlign.center,
                      ),
            ),
            SizedBox(
              height: 100,
            ),
            Padding(
              padding: const EdgeInsets.all(48.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
              children: [
              TextFormField(
                decoration: InputDecoration(
                  hintStyle: TextStyle(
                      color: Colors.white),
                  hintText: "Username",
                  border: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white))
                ),
              ),
              TextFormField(
              decoration:InputDecoration(
                   hintStyle:TextStyle(
                       color: Colors.white),
                  hintText: "Email",
                ),
              ),
              TextFormField(
                decoration: InputDecoration(
                  hintStyle: TextStyle(
                      color: Colors.white),
                  border:UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.white),
                  ),
                  hintText: "Password",
                ),
              ),
              SizedBox(
                height: 60,
              ),
              Container(
                height: 70,
                width: 320,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(
                      Colors.white,
                    ),
                  ),
                      onPressed:(){
                    Navigator.push(context,MaterialPageRoute(builder: (context)=>Hakunamatanamsmafrica()));
                      },
                      child: Text(
                        "SIGN UP",
                        style: TextStyle(
                            color: Color(customColor('#994c8a'),
                            ),
                            fontSize: 25
                        ),
                      )
                  ),
              ),
                  ],
                  ),
            ),
      ],
        ),
    ),
    );
  }
}
int customColor(String colorCode) {
  String colors = "0xff" + colorCode;
  colors = colors.replaceAll("#", "");
  return int.parse(colors);
}