import 'package:flutter/material.dart';

class Hakunamatanamsmafrica extends StatefulWidget {
  const Hakunamatanamsmafrica({super.key});

  @override
  State<Hakunamatanamsmafrica> createState() => _HakunamatanamsmafricaState();
}

class _HakunamatanamsmafricaState extends State<Hakunamatanamsmafrica> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
