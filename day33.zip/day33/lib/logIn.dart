import 'package:day33/signUp.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset("assets/Screenshot 2024-12-31 172200.jpg",
            scale: 0.1,
            ),
            SizedBox(
              height: 100,
            ),
            Center(
              child: Container(
                width: 275,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextFormField(
                      decoration: InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: "Username",
                      ),
                    ),
                    TextFormField(
                      decoration: InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: "Password",
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: (){},
                            child:
                            Text('Forgot it?',
                              style: TextStyle(
                                color: Color(customColor("#dfdbdc")),
                              ),
                            ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Signup()));
                      },
                      child:
                      Container(
                        height: 40,
                        width: 270,
                        decoration:BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFFb76a83),
                              Color(0xFFfbb86a),
                              Color(0xFFe29c8f),
                          ],
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text('LOG In',
                          style: TextStyle(color: Colors.white,
                          fontSize: 15),
                          textAlign: TextAlign.center,),
                        ),
                      ),
                    ),
    ],
            ),
                      ),
    ),
      ],
    ),
    ),
            );
  }
}
int customColor(String colorCode) {
  String colors = "0xff" + colorCode;
  colors = colors.replaceAll("#", "");
  return int.parse(colors);
}