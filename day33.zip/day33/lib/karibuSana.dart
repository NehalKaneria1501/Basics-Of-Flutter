import 'package:day33/logIn.dart';
import 'package:flutter/material.dart';

class Karibusana extends StatefulWidget {
  const Karibusana({super.key});

  @override
  State<Karibusana> createState() => _KaribusanaState();
}

class _KaribusanaState extends State<Karibusana> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.passthrough,
        children: [
          Container(
            height: 900,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFFfbb86a),
                  Color(0xFFe29c8f),
                  Color(0xFFb76a83),
                  Color(0xFF994c8a),
                ],
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: 150,
              ),
              Center(
                child: RichText(
                  text: TextSpan(
                    children: <TextSpan>[
                      TextSpan(
                        text: 'WELCOME\n',
                        style: TextStyle(color: Colors.purple,
                          fontSize: 55,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      TextSpan(
                        text: 'ON BOARD',
                        style: TextStyle(color: Colors.white,
                          fontSize: 33,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(
                height: 50,
              ),
              Center(
                child: RichText(
                  text: TextSpan(
                    children: <TextSpan>[
                      TextSpan(
                        text: 'All the fun starts here!\n',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                      TextSpan(
                        text: 'Wanna feel these happy vibes?\n',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      TextSpan(
                        text: 'Create an account and\n',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      TextSpan(
                        text: 'you are set to go!\n',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              Image.asset("assets/Screenshot 2024-12-31 155543.jpg"),
              Container(
                height: 60,
                width: 320,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(
                      Colors.white,
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Login()));
                  },
                  child: Text(
                    "SIGN UP",
                    style: TextStyle(
                      color: Color(customColor('#994c8a'),
                      ),
                      fontSize: 25
                    ),
                  ),
                    ),
                  ),
              SizedBox(
                height: 10,
              ),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'Have an account?Cool!\n',
                      style: TextStyle(
                          color: Colors.white
                      ),
                    ),
                    WidgetSpan(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: ()
                            {
                              Navigator.push(context, MaterialPageRoute(
                                  builder: (context) => Login()
                              ),
                              );
                            },
                            child: Text('Login',
                              style: TextStyle(
                                  color: Colors.white,
                                  decoration: TextDecoration.underline,
                                  decorationColor: Colors.white
                              ),
                            ),
                          ),
                          Text('then !',
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
                ],
              ),

            ],
          ),
    );
  }

}
int customColor(String colorCode) {
  String colors = "0xff" + colorCode;
  colors = colors.replaceAll("#", "");
  return int.parse(colors);
}