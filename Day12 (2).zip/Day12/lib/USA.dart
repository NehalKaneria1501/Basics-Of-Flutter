import 'package:flutter/material.dart';

class Usa extends StatefulWidget {
  const Usa({super.key});

  @override
  State<Usa> createState() => _UsaState();
}

class _UsaState extends State<Usa> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        title: Text(
          "BYKS",
          style: TextStyle(fontSize: 24, color: Colors.redAccent),
        ),
        actions: [Icon(Icons.account_circle)],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(10),
              child: ButtonBar(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ElevatedButton(
                    child: Text("New Jersey"),
                    onPressed: () {
                      // Action for New Jersey
                    },
                  ),
                  TextButton(
                    child: Text("Florida"),
                    style: TextButton.styleFrom(backgroundColor: Colors.redAccent),
                    onPressed: () {
                      // Action for Florida
                    },
                  ),
                  TextButton(
                    child: Text("Arizona"),
                    style: TextButton.styleFrom(backgroundColor: Colors.blueAccent),
                    onPressed: () {
                      // Action for Arizona
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}