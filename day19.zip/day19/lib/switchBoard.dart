import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';

class Switchboard extends StatefulWidget {
  const Switchboard({super.key});

  @override
  State<Switchboard> createState() => _SwitchboardState();
}

class _SwitchboardState extends State<Switchboard> {
  Switchboard createState() => new Switchboard();
  bool status =false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blueAccent,
          title: Text("Flutter Switch Example"),
        ),
        body: Center(
          child: FlutterSwitch(
              width: 100,
            height: 100,
            valueFontSize: 25,
            toggleSize: 45,
            value: status,
            borderRadius: 30,
            padding: 8,
            showOnOff: true,
            onToggle: (val){
                setState(() {
                  status=val;
                });
            },
          ),
        )
    );
  }
}
// class Switchscreen extends StatefulWidget {
//   const Switchscreen({super.key});
//
//   @override
//   State<Switchscreen> createState() => _SwitchscreenState();
// }
//
// class _SwitchscreenState extends State<Switchscreen> {
//   bool isSwitched = false;
//   // var textValue='Switch is Off';
//   // void toggleSwitch(bool value)
//   // {
//   //   if(isSwitched==false)
//   //     {
//   //       setState(() {
//   //         isSwitched=true;
//   //         textValue = 'Switch Button is ON';
//   //       });
//   //       print('Switch Button is ON');
//   //     }
//   //   else
//   //     {
//   //       setState(() {
//   //
//   //         isSwitched=false;
//   //         textValue = 'Switch Button is OFF';
//   //       });
//   //       print('Switch Button is OFF');
//   //     }
//   // }
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         FlutterSwitch(
//             value: isSwitched,
//             onToggle: val,
//           activeColor: Colors.blue,
//           onChanged:(val){
//               print("VALUE:$val");
//               setState(() {
//                 isSwitched=val;
//                 textValue="Switch Button is ON";
//               });
//           }
//         )
//         // Transform.scale(
//         //   scale: 2,
//         //   child: Switch(
//         //     onChanged: toggleSwitch,
//         //     value: isSwitched,
//         //     activeColor: Colors.blue,
//         //     activeTrackColor: Colors.yellow,
//         //     inactiveThumbColor: Colors.redAccent,
//         //     inactiveTrackColor: Colors.orange,
//         //   ),
//         // ),
//         // Text('$textValue',style: TextStyle(fontSize: 25),)
//       ],
//     );
//   }
// }
