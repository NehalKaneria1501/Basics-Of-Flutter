import 'package:flutter/material.dart';

class Thematicicon extends StatefulWidget {
  const Thematicicon({super.key});

  @override
  State<Thematicicon> createState() => _ThematiciconState();
}

class _ThematiciconState extends State<Thematicicon> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Flutter "),
        actions: [Icon(Icons.theater_comedy_outlined)],
      ),
      body: Center(
        child: Container(
          color: Theme.of(context).colorScheme.secondary,
          child: Text("Themes contains the graphical apperances that makes the user interface more attractive",
          style: Theme.of(context).textTheme.headlineMedium,
          ),
        ),
      ),
      floatingActionButton: Theme(
          data: Theme.of(context).copyWith(
              colorScheme:Theme.of(context).colorScheme.copyWith(secondary: Colors.blue),
          ),
        child: FloatingActionButton(onPressed: null,
        child: Icon(Icons.person),),
      ),
    );
  }
}
