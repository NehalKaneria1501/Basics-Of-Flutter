package com.example.day24

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
